@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js not found. Please install Node.js 18+ first.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo npm not found. Please make sure Node.js and npm are installed.
  pause
  exit /b 1
)

echo Building catalog...
call npm run build
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)

echo Starting server...
start "" "http://127.0.0.1:5173"
call npm start
if errorlevel 1 (
  echo Server exited with an error.
  pause
  exit /b 1
)

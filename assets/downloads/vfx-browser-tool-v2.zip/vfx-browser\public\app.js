const searchEl = document.getElementById("search");
const versionFilterEl = document.getElementById("version-filter");
const globalFpsEl = document.getElementById("global-fps");
const statusEl = document.getElementById("status");
const syncStatusEl = document.getElementById("sync-status");
const gridEl = document.getElementById("grid");
const emptyEl = document.getElementById("empty");
const contentPanelEl = document.querySelector(".content-panel");
const folderResizerEl = document.getElementById("folder-resizer");
const colorTagsEl = document.getElementById("color-tags");
const functionTagsEl = document.getElementById("function-tags");
const viewTagsEl = document.getElementById("view-tags");
const folderTreeEl = document.getElementById("folder-tree");
const previewModalEl = document.getElementById("preview-modal");
const previewCloseEl = document.getElementById("preview-close");
const previewTitleEl = document.getElementById("preview-title");
const previewSubtitleEl = document.getElementById("preview-subtitle");
const previewCanvasEl = document.getElementById("preview-canvas");
const previewResizerEl = document.getElementById("preview-resizer");
const backgroundInputEl = document.getElementById("background-input");
const itemInputEl = document.getElementById("item-input");
const backgroundStripEl = document.getElementById("background-strip");
const itemStripEl = document.getElementById("item-strip");
const effectScaleEl = document.getElementById("effect-scale");
const scaleValueEl = document.getElementById("scale-value");
const frameListEl = document.getElementById("frame-list");
const frameCountLabelEl = document.getElementById("frame-count-label");
const frameCountSliderEl = document.getElementById("frame-count-slider");
const frameSliderMaxEl = document.getElementById("frame-slider-max");
const frameSliderValueEl = document.getElementById("frame-slider-value");
const frameCurrentLabelEl = document.getElementById("frame-current-label");
const exportOriginalEl = document.getElementById("export-original");
const exportScaledEl = document.getElementById("export-scaled");
const keyBackgroundEl = document.getElementById("key-background");
const keyBackgroundWrapEl = document.querySelector(".key-toggle");
const keyBackgroundLabelEl = document.querySelector(".key-background-label");
const settingsButtonEl = document.getElementById("settings-button");
const settingsMenuEl = document.getElementById("settings-menu");

let catalog = null;
let userState = { trashIds: [] };
let filtered = [];
/** @type {Map<string, { card: HTMLElement, sequence: object, player?: SequencePlayer }>} */
const cards = new Map();

const selectedColors = new Set();
const selectedFunctions = new Set();
let viewMode = "all";
let selectedFolder = "";
let renderedCount = 0;

const POLL_MS = 30000;
const INITIAL_RENDER_COUNT = 80;
const RENDER_BATCH_SIZE = 80;
const FPS_STORAGE_KEY = "vfx-browser:fps";
const LANGUAGE_STORAGE_KEY = "vfx-browser:language";
const PREVIEW_WIDTH_STORAGE_KEY = "vfx-browser:preview-width";
const FOLDER_WIDTH_STORAGE_KEY = "vfx-browser:folder-width";
const BACKGROUND_DB_NAME = "vfx-preview-backgrounds";
const BACKGROUND_STORE_NAME = "backgrounds";
const ITEM_STORE_NAME = "items";
const expandedFolders = new Set([""]);

const translations = {
  "zh-CN": {
    title: "VFX 序列浏览器",
    search: "搜索特效名或路径...",
    allFolders: "全部目录",
    color: "颜色",
    function: "功能",
    view: "视图",
    folders: "文件夹",
    language: "语言",
    sequenceFrames: "序列帧",
    background: "背景",
    items: "物品",
    noBackground: "无背景",
    scale: "缩放",
    exportTitle: "导出 Sprite Sheet",
    exportOriginal: "按原大导出",
    exportScaled: "按修改后尺寸导出",
    totalFrames: "当前总帧数",
    openFolder: "打开文件夹",
    all: "全部",
    trashDuplicates: "Trash / 重复",
    frames: "帧",
    gif: "GIF",
    restore: "恢复",
    restoreTitle: "从 Trash 恢复",
    moveTrash: "移到 Trash",
    duplicate: "重复",
    addBackground: "添加背景",
    addItem: "添加物品",
    removeItem: "移除物品",
    openedFolder: "已打开文件夹",
    openFolderFailed: "打开文件夹失败",
    removeBackground: "去除背景",
    removeSavedBackground: "移除背景",
    openPreview: "打开大图预览",
    duplicateOf: "与 {id} 相同",
    filters: "分类筛选",
    close: "关闭",
    previewEditor: "特效预览编辑器",
    dragFolderWidth: "拖拽调整文件夹栏宽度",
    dragPreviewWidth: "拖拽调整宽度",
    missingCatalog: "未找到 catalog.json。",
    runToolDir: "请在工具目录运行：",
    sync: "同步",
    itemCount: "条",
    languages: "简体中文",
    colors: {
      red: "红", orange: "橙", yellow: "黄", green: "绿", cyan: "青", blue: "蓝",
      purple: "紫", pink: "粉", white: "白", gold: "金", black: "黑", multi: "多彩",
    },
    functions: {
      heal: "加血", fire: "火焰", ice: "冰冻", poison: "毒", explosion: "爆炸",
      lightning: "闪电", wind: "风", holy: "光", dark: "暗", hit: "受击",
      buff: "增益", debuff: "减益", ui: "UI", other: "其他",
    },
  },
  "zh-TW": {
    title: "VFX 序列瀏覽器",
    search: "搜尋特效名或路徑...",
    allFolders: "全部目錄",
    color: "顏色",
    function: "功能",
    view: "視圖",
    folders: "資料夾",
    language: "語言",
    sequenceFrames: "序列幀",
    background: "背景",
    items: "物品",
    noBackground: "無背景",
    scale: "縮放",
    exportTitle: "匯出 Sprite Sheet",
    exportOriginal: "按原尺寸匯出",
    exportScaled: "按修改後尺寸匯出",
    totalFrames: "目前總幀數",
    openFolder: "開啟資料夾",
    all: "全部",
    trashDuplicates: "Trash / 重複",
    frames: "幀",
    gif: "GIF",
    restore: "恢復",
    restoreTitle: "從 Trash 恢復",
    moveTrash: "移到 Trash",
    duplicate: "重複",
    addBackground: "新增背景",
    addItem: "新增物品",
    removeItem: "移除物品",
    openedFolder: "已開啟資料夾",
    openFolderFailed: "開啟資料夾失敗",
    removeBackground: "移除背景",
    removeSavedBackground: "移除背景",
    openPreview: "開啟大圖預覽",
    duplicateOf: "與 {id} 相同",
    filters: "分類篩選",
    close: "關閉",
    previewEditor: "特效預覽編輯器",
    dragFolderWidth: "拖曳調整資料夾欄寬度",
    dragPreviewWidth: "拖曳調整寬度",
    missingCatalog: "找不到 catalog.json。",
    runToolDir: "請在工具目錄執行：",
    sync: "同步",
    itemCount: "筆",
    languages: "繁體中文",
    colors: {
      red: "紅", orange: "橙", yellow: "黃", green: "綠", cyan: "青", blue: "藍",
      purple: "紫", pink: "粉", white: "白", gold: "金", black: "黑", multi: "多彩",
    },
    functions: {
      heal: "加血", fire: "火焰", ice: "冰凍", poison: "毒", explosion: "爆炸",
      lightning: "閃電", wind: "風", holy: "光", dark: "暗", hit: "受擊",
      buff: "增益", debuff: "減益", ui: "UI", other: "其他",
    },
  },
  en: {
    title: "VFX Sequence Browser",
    search: "Search effect name or path...",
    allFolders: "All folders",
    color: "Color",
    function: "Function",
    view: "View",
    folders: "Folders",
    language: "Language",
    sequenceFrames: "Frames",
    background: "Background",
    items: "Items",
    noBackground: "No background",
    scale: "Scale",
    exportTitle: "Export Sprite Sheet",
    exportOriginal: "Export Original Size",
    exportScaled: "Export Edited Size",
    totalFrames: "Total frames",
    openFolder: "Open Folder",
    all: "All",
    trashDuplicates: "Trash / Duplicates",
    frames: "frames",
    gif: "GIF",
    restore: "Restore",
    restoreTitle: "Restore from Trash",
    moveTrash: "Move to Trash",
    duplicate: "Duplicate",
    addBackground: "Add background",
    addItem: "Add item",
    removeItem: "Remove item",
    openedFolder: "Folder opened",
    openFolderFailed: "Open folder failed",
    removeBackground: "Remove background",
    removeSavedBackground: "Remove background",
    openPreview: "Open large preview",
    duplicateOf: "Same as {id}",
    filters: "Category filters",
    close: "Close",
    previewEditor: "VFX preview editor",
    dragFolderWidth: "Drag to resize folder column",
    dragPreviewWidth: "Drag to resize",
    missingCatalog: "catalog.json was not found.",
    runToolDir: "Run in the tool folder:",
    sync: "Synced",
    itemCount: "items",
    languages: "English",
    colors: {
      red: "Red", orange: "Orange", yellow: "Yellow", green: "Green", cyan: "Cyan", blue: "Blue",
      purple: "Purple", pink: "Pink", white: "White", gold: "Gold", black: "Black", multi: "Multi",
    },
    functions: {
      heal: "Heal", fire: "Fire", ice: "Ice", poison: "Poison", explosion: "Explosion",
      lightning: "Lightning", wind: "Wind", holy: "Light", dark: "Dark", hit: "Hit",
      buff: "Buff", debuff: "Debuff", ui: "UI", other: "Other",
    },
  },
  es: {
    title: "Explorador de Secuencias VFX",
    search: "Buscar nombre o ruta...",
    allFolders: "Todas las carpetas",
    color: "Color",
    function: "Función",
    view: "Vista",
    folders: "Carpetas",
    language: "Idioma",
    sequenceFrames: "Fotogramas",
    background: "Fondo",
    items: "Objetos",
    noBackground: "Sin fondo",
    scale: "Escala",
    exportTitle: "Exportar Sprite Sheet",
    exportOriginal: "Tamaño original",
    exportScaled: "Tamaño editado",
    totalFrames: "Fotogramas totales",
    openFolder: "Abrir carpeta",
    all: "Todo",
    trashDuplicates: "Papelera / Duplicados",
    frames: "fotogramas",
    gif: "GIF",
    restore: "Restaurar",
    restoreTitle: "Restaurar desde papelera",
    moveTrash: "Mover a papelera",
    duplicate: "Duplicado",
    addBackground: "Agregar fondo",
    addItem: "Agregar objeto",
    removeItem: "Quitar objeto",
    openedFolder: "Carpeta abierta",
    openFolderFailed: "No se pudo abrir",
    removeBackground: "Quitar fondo",
    removeSavedBackground: "Quitar fondo",
    openPreview: "Abrir vista grande",
    duplicateOf: "Igual que {id}",
    filters: "Filtros de categoría",
    close: "Cerrar",
    previewEditor: "Editor de vista VFX",
    dragFolderWidth: "Arrastra para cambiar el ancho de carpetas",
    dragPreviewWidth: "Arrastra para cambiar el ancho",
    missingCatalog: "No se encontró catalog.json.",
    runToolDir: "Ejecuta en la carpeta de la herramienta:",
    sync: "Sincronizado",
    itemCount: "elementos",
    languages: "Español",
    colors: {
      red: "Rojo", orange: "Naranja", yellow: "Amarillo", green: "Verde", cyan: "Cian", blue: "Azul",
      purple: "Morado", pink: "Rosa", white: "Blanco", gold: "Dorado", black: "Negro", multi: "Multicolor",
    },
    functions: {
      heal: "Curar", fire: "Fuego", ice: "Hielo", poison: "Veneno", explosion: "Explosión",
      lightning: "Rayo", wind: "Viento", holy: "Luz", dark: "Oscuro", hit: "Golpe",
      buff: "Mejora", debuff: "Debuff", ui: "UI", other: "Otro",
    },
  },
  fr: {
    title: "Navigateur de Séquences VFX",
    search: "Rechercher un nom ou chemin...",
    allFolders: "Tous les dossiers",
    color: "Couleur",
    function: "Fonction",
    view: "Vue",
    folders: "Dossiers",
    language: "Langue",
    sequenceFrames: "Images",
    background: "Arrière-plan",
    items: "Objets",
    noBackground: "Sans fond",
    scale: "Échelle",
    exportTitle: "Exporter Sprite Sheet",
    exportOriginal: "Taille originale",
    exportScaled: "Taille modifiée",
    totalFrames: "Images totales",
    openFolder: "Ouvrir le dossier",
    all: "Tout",
    trashDuplicates: "Corbeille / Doublons",
    frames: "images",
    gif: "GIF",
    restore: "Restaurer",
    restoreTitle: "Restaurer depuis la corbeille",
    moveTrash: "Mettre à la corbeille",
    duplicate: "Doublon",
    addBackground: "Ajouter un fond",
    addItem: "Ajouter un objet",
    removeItem: "Supprimer l'objet",
    openedFolder: "Dossier ouvert",
    openFolderFailed: "Ouverture impossible",
    removeBackground: "Supprimer le fond",
    removeSavedBackground: "Supprimer le fond",
    openPreview: "Ouvrir le grand aperçu",
    duplicateOf: "Identique à {id}",
    filters: "Filtres de catégorie",
    close: "Fermer",
    previewEditor: "Éditeur d'aperçu VFX",
    dragFolderWidth: "Faites glisser pour redimensionner les dossiers",
    dragPreviewWidth: "Faites glisser pour redimensionner",
    missingCatalog: "catalog.json est introuvable.",
    runToolDir: "Exécutez dans le dossier de l'outil :",
    sync: "Synchronisé",
    itemCount: "éléments",
    languages: "Français",
    colors: {
      red: "Rouge", orange: "Orange", yellow: "Jaune", green: "Vert", cyan: "Cyan", blue: "Bleu",
      purple: "Violet", pink: "Rose", white: "Blanc", gold: "Or", black: "Noir", multi: "Multicolore",
    },
    functions: {
      heal: "Soin", fire: "Feu", ice: "Glace", poison: "Poison", explosion: "Explosion",
      lightning: "Éclair", wind: "Vent", holy: "Lumière", dark: "Sombre", hit: "Impact",
      buff: "Bonus", debuff: "Malus", ui: "UI", other: "Autre",
    },
  },
  ja: {
    title: "VFX シーケンスブラウザー",
    search: "エフェクト名またはパスを検索...",
    allFolders: "すべてのフォルダー",
    color: "色",
    function: "機能",
    view: "表示",
    folders: "フォルダー",
    language: "言語",
    sequenceFrames: "フレーム",
    background: "背景",
    items: "アイテム",
    noBackground: "背景なし",
    scale: "スケール",
    exportTitle: "Sprite Sheet を書き出し",
    exportOriginal: "元サイズで書き出し",
    exportScaled: "編集サイズで書き出し",
    totalFrames: "現在の総フレーム数",
    openFolder: "フォルダーを開く",
    all: "すべて",
    trashDuplicates: "Trash / 重複",
    frames: "フレーム",
    gif: "GIF",
    restore: "復元",
    restoreTitle: "Trash から復元",
    moveTrash: "Trash へ移動",
    duplicate: "重複",
    addBackground: "背景を追加",
    addItem: "アイテムを追加",
    removeItem: "アイテムを削除",
    openedFolder: "フォルダーを開きました",
    openFolderFailed: "フォルダーを開けません",
    removeBackground: "背景を削除",
    removeSavedBackground: "背景を削除",
    openPreview: "大きなプレビューを開く",
    duplicateOf: "{id} と同じ",
    filters: "カテゴリフィルター",
    close: "閉じる",
    previewEditor: "VFX プレビューエディター",
    dragFolderWidth: "ドラッグしてフォルダー幅を調整",
    dragPreviewWidth: "ドラッグして幅を調整",
    missingCatalog: "catalog.json が見つかりません。",
    runToolDir: "ツールフォルダーで実行:",
    sync: "同期",
    itemCount: "件",
    languages: "日本語",
    colors: {
      red: "赤", orange: "橙", yellow: "黄", green: "緑", cyan: "シアン", blue: "青",
      purple: "紫", pink: "ピンク", white: "白", gold: "金", black: "黒", multi: "多色",
    },
    functions: {
      heal: "回復", fire: "炎", ice: "氷", poison: "毒", explosion: "爆発",
      lightning: "雷", wind: "風", holy: "光", dark: "闇", hit: "ヒット",
      buff: "強化", debuff: "弱体", ui: "UI", other: "その他",
    },
  },
  ko: {
    title: "VFX 시퀀스 브라우저",
    search: "이펙트 이름 또는 경로 검색...",
    allFolders: "모든 폴더",
    color: "색상",
    function: "기능",
    view: "보기",
    folders: "폴더",
    language: "언어",
    sequenceFrames: "프레임",
    background: "배경",
    items: "아이템",
    noBackground: "배경 없음",
    scale: "크기",
    exportTitle: "Sprite Sheet 내보내기",
    exportOriginal: "원본 크기로 내보내기",
    exportScaled: "수정한 크기로 내보내기",
    totalFrames: "현재 총 프레임 수",
    openFolder: "폴더 열기",
    all: "전체",
    trashDuplicates: "Trash / 중복",
    frames: "프레임",
    gif: "GIF",
    restore: "복원",
    restoreTitle: "Trash에서 복원",
    moveTrash: "Trash로 이동",
    duplicate: "중복",
    addBackground: "배경 추가",
    addItem: "아이템 추가",
    removeItem: "아이템 제거",
    openedFolder: "폴더를 열었습니다",
    openFolderFailed: "폴더 열기 실패",
    removeBackground: "배경 제거",
    removeSavedBackground: "배경 제거",
    openPreview: "큰 미리보기 열기",
    duplicateOf: "{id}와 동일",
    filters: "분류 필터",
    close: "닫기",
    previewEditor: "VFX 미리보기 편집기",
    dragFolderWidth: "드래그해서 폴더 열 너비 조정",
    dragPreviewWidth: "드래그해서 너비 조정",
    missingCatalog: "catalog.json을 찾을 수 없습니다.",
    runToolDir: "도구 폴더에서 실행:",
    sync: "동기화",
    itemCount: "개",
    languages: "한국어",
    colors: {
      red: "빨강", orange: "주황", yellow: "노랑", green: "초록", cyan: "청록", blue: "파랑",
      purple: "보라", pink: "분홍", white: "흰색", gold: "금색", black: "검정", multi: "다색",
    },
    functions: {
      heal: "회복", fire: "화염", ice: "빙결", poison: "독", explosion: "폭발",
      lightning: "번개", wind: "바람", holy: "빛", dark: "어둠", hit: "피격",
      buff: "버프", debuff: "디버프", ui: "UI", other: "기타",
    },
  },
};

let currentLanguage = "zh-CN";

function t(key) {
  return translations[currentLanguage]?.[key] ?? translations["zh-CN"][key] ?? key;
}

function tagText(group, item) {
  return translations[currentLanguage]?.[group]?.[item.id] ?? item.label;
}

function activeScrollTarget() {
  if (
    contentPanelEl &&
    getComputedStyle(contentPanelEl).overflowY !== "visible" &&
    contentPanelEl.scrollHeight > contentPanelEl.clientHeight + 1
  ) {
    return contentPanelEl;
  }
  return document.scrollingElement || document.documentElement;
}

function currentScrollTop() {
  const target = activeScrollTarget();
  return target === contentPanelEl ? target.scrollTop : window.scrollY || target.scrollTop;
}

function setCurrentScrollTop(value) {
  const target = activeScrollTarget();
  if (target === contentPanelEl) target.scrollTop = value;
  else window.scrollTo(0, value);
}

function currentClientHeight() {
  const target = activeScrollTarget();
  return target === contentPanelEl ? target.clientHeight : window.innerHeight;
}

function currentScrollHeight() {
  const target = activeScrollTarget();
  if (target === contentPanelEl) return target.scrollHeight;
  return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
}

function restoreScrollAfterRender(previousScrollTop) {
  if (previousScrollTop <= 0) return;
  while (
    renderedCount < filtered.length &&
    currentScrollHeight() < previousScrollTop + currentClientHeight() + 900
  ) {
    renderMoreCards();
  }
  requestAnimationFrame(() => {
    setCurrentScrollTop(previousScrollTop);
  });
}

function mediaUrl(relDir, file) {
  const dir = relDir.split("/").map(encodeURIComponent).join("/");
  return `/media/${dir}/${encodeURIComponent(file)}`;
}

function globalFps() {
  return Math.max(1, Math.min(60, Number(globalFpsEl.value) || 24));
}

function setFpsInputs(value) {
  const fps = String(Math.max(1, Math.min(60, Number(value) || 24)));
  globalFpsEl.value = fps;
}

function loadSavedFps() {
  const saved = Number(localStorage.getItem(FPS_STORAGE_KEY));
  if (!Number.isFinite(saved)) return;
  setFpsInputs(saved);
}

function saveFps() {
  localStorage.setItem(FPS_STORAGE_KEY, String(globalFps()));
}

function applyFpsChange(value) {
  setFpsInputs(value);
  saveFps();
  const fps = globalFps();
  for (const { player } of cards.values()) {
    player?.setFps(fps);
  }
}

let previewTransform = { scale: 100, bgXRatio: 0.5, bgYRatio: 0.5, bgScaleRatio: 0.25 };
let preferNoBackground = false;

function rememberPreviewTransform() {
  if (!previewState) return;
  const basis = previewTransformBasis();
  previewTransform = {
    scale: previewState.scale,
    bgXRatio: basis.w ? (previewState.x - basis.x) / basis.w : 0.5,
    bgYRatio: basis.h ? (previewState.y - basis.y) / basis.h : 0.5,
    bgScaleRatio: basis.base ? previewState.scale / basis.base : 0.25,
  };
}

function applyLanguage(lang) {
  currentLanguage = translations[lang] ? lang : "zh-CN";
  document.documentElement.lang = currentLanguage;
  localStorage.setItem(LANGUAGE_STORAGE_KEY, currentLanguage);
  settingsMenuEl.querySelectorAll("[data-lang]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.lang === currentLanguage);
  });
  translatePage();
}

function loadSavedLanguage() {
  applyLanguage(localStorage.getItem(LANGUAGE_STORAGE_KEY) || "zh-CN");
}

function applySavedPreviewWidth() {
  const width = Number(localStorage.getItem(PREVIEW_WIDTH_STORAGE_KEY));
  if (Number.isFinite(width) && width > 320) {
    setPreviewWidth(width);
  }
}

function setPreviewWidth(width) {
  const finalWidth = Math.min(window.innerWidth - 260, Math.max(360, width));
  previewModalEl.style.width = `${finalWidth}px`;
  document.documentElement.style.setProperty("--preview-width", `${finalWidth}px`);
}

function setFolderWidth(width) {
  const finalWidth = Math.min(520, Math.max(180, width));
  document.documentElement.style.setProperty("--folder-width", `${finalWidth}px`);
  localStorage.setItem(FOLDER_WIDTH_STORAGE_KEY, String(finalWidth));
}

function applySavedFolderWidth() {
  const width = Number(localStorage.getItem(FOLDER_WIDTH_STORAGE_KEY));
  if (Number.isFinite(width)) setFolderWidth(width);
}

function translatePage() {
  document.title = t("title");
  document.querySelector(".title").textContent = t("title");
  searchEl.placeholder = t("search");
  versionFilterEl.options[0].textContent = t("allFolders");
  document.querySelectorAll(".tag-row-label")[0].textContent = t("color");
  document.querySelectorAll(".tag-row-label")[1].textContent = t("function");
  document.querySelectorAll(".tag-row-label")[2].textContent = t("view");
  document.querySelector(".folder-panel-title").textContent = t("folders");
  settingsButtonEl.textContent = t("language");
  settingsButtonEl.innerHTML = `<span>${t("language")}</span><span class="settings-current">${t("languages")}</span><span class="settings-arrow">▾</span>`;
  document.querySelector(".settings-title").textContent = t("language");
  document.querySelector(".item-title").textContent = t("items");
  document.querySelector(".background-title").textContent = t("background");
  document.querySelector(".frame-panel-head span").textContent = t("sequenceFrames");
  document.querySelector(".scale-title").textContent = t("scale");
  document.querySelector(".export-heading").textContent = t("exportTitle");
  exportOriginalEl.textContent = t("exportOriginal");
  exportScaledEl.textContent = t("exportScaled");
  keyBackgroundLabelEl.textContent = t("removeBackground");
  document.querySelector(".tag-bar")?.setAttribute("aria-label", t("filters"));
  document.querySelector(".folder-panel")?.setAttribute("aria-label", t("folders"));
  versionFilterEl.setAttribute("aria-label", t("folders"));
  previewModalEl.setAttribute("aria-label", t("previewEditor"));
  previewCloseEl.setAttribute("aria-label", t("close"));
  folderResizerEl.title = t("dragFolderWidth");
  previewResizerEl.title = t("dragPreviewWidth");
  const emptyLines = emptyEl.querySelectorAll("p");
  if (emptyLines[0]) emptyLines[0].textContent = t("missingCatalog");
  if (emptyLines[1]) emptyLines[1].innerHTML = `${t("runToolDir")}<code>npm run build</code>`;
  renderItemStrip();
  renderBackgroundStrip();
  renderTagBars();
  updateFrameLabels();
  if (catalog) applyFilters();
}

function isInTrash(sequence) {
  return userState.trashIds.includes(sequence.id);
}

function isAutoDuplicate(sequence) {
  return Boolean(sequence.duplicateOf || sequence.autoTrash);
}

function allSequences() {
  if (!catalog) return [];
  return [...(catalog.sequences ?? []), ...(catalog.duplicates ?? [])];
}

function trashPool() {
  const manual = new Set(userState.trashIds);
  const items = allSequences().filter(
    (s) => manual.has(s.id) || isAutoDuplicate(s)
  );
  const seen = new Set();
  return items.filter((s) => {
    if (seen.has(s.id)) return false;
    seen.add(s.id);
    return true;
  });
}

function isGif(sequence) {
  return sequence.type === "gif" || /\.gif$/i.test(sequence.poster || "");
}

function spriteSheetLayout(img) {
  if (!img) return null;
  const ratio = img.width / img.height;
  if (ratio >= 3.8 && img.width >= 900) {
    const cols = Math.min(32, Math.max(4, Math.round(ratio)));
    return { cols, rows: 1, count: cols, cellW: img.width / cols, cellH: img.height };
  }
  if (ratio <= 0.26 && img.height >= 900) {
    const rows = Math.min(32, Math.max(4, Math.round(1 / ratio)));
    return { cols: 1, rows, count: rows, cellW: img.width, cellH: img.height / rows };
  }
  if (img.width >= 1200 && img.height >= 900) {
    for (const cols of [8, 6, 5, 4]) {
      const cell = img.width / cols;
      const rows = Math.round(img.height / cell);
      if (rows >= 3 && rows <= 12 && Math.abs(img.height / rows - cell) / cell < 0.08) {
        return { cols, rows, count: cols * rows, cellW: img.width / cols, cellH: img.height / rows };
      }
    }
  }
  return null;
}

function virtualFrameCount(sequence, images) {
  if (!isGif(sequence)) return sequence.frames.length;
  return spriteSheetLayout(images?.[0])?.count ?? sequence.frames.length;
}

function sourceFrameName(sequence, index) {
  if (!isGif(sequence)) return sequence.frames[index];
  return `${sequence.poster}#${index + 1}`;
}

function folderMatches(sequence) {
  if (!selectedFolder) return true;
  return sequence.relDir === selectedFolder || sequence.relDir.startsWith(`${selectedFolder}/`);
}

function naturalCompare(a, b) {
  return a.localeCompare(b, "zh-CN", { numeric: true, sensitivity: "base" });
}

function ensureFolderExpanded(folder) {
  expandedFolders.add("");
  if (!folder) return;
  const parts = folder.split("/");
  for (let i = 1; i <= parts.length; i++) {
    expandedFolders.add(parts.slice(0, i).join("/"));
  }
}

class SequencePlayer {
  constructor(canvas, sequence, { fps = 24 } = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.sequence = sequence;
    this.fps = fps;
    this.frameIndex = 0;
    this.playing = false;
    this.lastTime = 0;
    this.accum = 0;
    this.images = [];
    this.sheet = null;
    this.loaded = false;
    this.visible = false;
    this.rafId = null;
  }

  async load() {
    if (this.loaded) return;
    const { relDir, frames } = this.sequence;
    this.images = await Promise.all(
      frames.map(
        (file) =>
          new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = reject;
            img.src = mediaUrl(relDir, file);
          })
      )
    );
    if (isGif(this.sequence)) {
      this.sheet = spriteSheetLayout(this.images[0]);
    }
    this.loaded = true;
    this.drawFrame(0);
  }

  drawFrame(index) {
    const img = this.sheet ? this.images[0] : this.images[index];
    if (!img) return;
    const maxW = this.canvas.clientWidth || 200;
    const maxH = this.canvas.clientHeight || 200;
    const srcW = this.sheet ? this.sheet.cellW : img.width;
    const srcH = this.sheet ? this.sheet.cellH : img.height;
    const scale = Math.min(maxW / srcW, maxH / srcH, 1);
    const w = Math.max(1, Math.round(srcW * scale));
    const h = Math.max(1, Math.round(srcH * scale));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
    this.ctx.clearRect(0, 0, w, h);
    if (this.sheet) {
      const col = index % this.sheet.cols;
      const row = Math.floor(index / this.sheet.cols);
      this.ctx.drawImage(
        img,
        col * this.sheet.cellW,
        row * this.sheet.cellH,
        this.sheet.cellW,
        this.sheet.cellH,
        0,
        0,
        w,
        h
      );
    } else {
      this.ctx.drawImage(img, 0, 0, w, h);
    }
    this.frameIndex = index;
  }

  tick(now) {
    if (!this.playing || !this.visible) {
      this.rafId = requestAnimationFrame((t) => this.tick(t));
      return;
    }
    if (!this.lastTime) this.lastTime = now;
    const dt = now - this.lastTime;
    this.lastTime = now;
    this.accum += dt;
    const frameMs = 1000 / this.fps;
    const total = this.sheet?.count ?? this.images.length;
    while (this.accum >= frameMs && total) {
      this.accum -= frameMs;
      let next = this.frameIndex + 1;
      if (next >= total) next = 0;
      this.drawFrame(next);
    }
    this.rafId = requestAnimationFrame((t) => this.tick(t));
  }

  play() {
    this.playing = true;
    if (!this.rafId) {
      this.rafId = requestAnimationFrame((t) => this.tick(t));
    }
  }

  pause() {
    this.playing = false;
  }

  setVisible(v) {
    this.visible = v;
    if (v && this.loaded) this.play();
    else this.pause();
  }

  setFps(fps) {
    this.fps = fps;
  }

  destroy() {
    this.pause();
    if (this.rafId) cancelAnimationFrame(this.rafId);
    this.rafId = null;
    this.images = [];
    this.loaded = false;
  }
}

let previewState = null;
let backgroundDbPromise = null;
let savedBackgrounds = [];
let activeBackground = null;
let exportScaleMode = "scaled";
let editorItems = [];
let selectedItemId = null;
let itemDrag = null;

function openBackgroundDb() {
  if (backgroundDbPromise) return backgroundDbPromise;
  backgroundDbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(BACKGROUND_DB_NAME, 2);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(BACKGROUND_STORE_NAME)) {
        req.result.createObjectStore(BACKGROUND_STORE_NAME, { keyPath: "id" });
      }
      if (!req.result.objectStoreNames.contains(ITEM_STORE_NAME)) {
        req.result.createObjectStore(ITEM_STORE_NAME, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return backgroundDbPromise;
}

async function dbStore(storeName, mode, callback) {
  const db = await openBackgroundDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, mode);
    const store = tx.objectStore(storeName);
    const result = callback(store);
    tx.oncomplete = () => resolve(result);
    tx.onerror = () => reject(tx.error);
  });
}

async function backgroundStore(mode, callback) {
  return dbStore(BACKGROUND_STORE_NAME, mode, callback);
}

async function itemStore(mode, callback) {
  return dbStore(ITEM_STORE_NAME, mode, callback);
}

async function loadSavedBackgrounds() {
  savedBackgrounds = await backgroundStore("readonly", (store) => {
    const req = store.getAll();
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result ?? []);
      req.onerror = () => reject(req.error);
    });
  }).catch(() => []);
  savedBackgrounds.sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0));
  const first = savedBackgrounds[0];
  if (first && !activeBackground && !preferNoBackground) {
    activeBackground = { ...first, image: await loadImage(first.dataUrl).catch(() => null) };
  }
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

function isImageFile(file) {
  return /image\/(png|jpeg|gif)/i.test(file.type) || /\.(png|jpe?g|gif)$/i.test(file.name);
}

function sortFilesByName(files) {
  return [...files].sort((a, b) => a.name.localeCompare(b.name, "zh-CN", { numeric: true, sensitivity: "base" }));
}

function looksLikeKeyableImage(img) {
  if (!img?.width || !img?.height) return false;
  const canvas = document.createElement("canvas");
  const size = 24;
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  ctx.drawImage(img, 0, 0, size, size);
  const data = ctx.getImageData(0, 0, size, size).data;
  let keyable = 0;
  let solid = 0;
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
    if (a < 240) continue;
    solid++;
    const black = r < 34 && g < 34 && b < 34;
    const green = g > 90 && g > r * 1.45 && g > b * 1.45;
    if (black || green) keyable++;
  }
  return solid > 40 && keyable / solid > 0.45;
}

function previewHasKeyableBackground() {
  if (!previewState) return false;
  return previewState.images.some((img) => looksLikeKeyableImage(img));
}

function updateKeyBackgroundVisibility() {
  const visible = previewHasKeyableBackground();
  keyBackgroundWrapEl.classList.toggle("hidden", !visible);
  if (!visible) keyBackgroundEl.checked = false;
}

async function saveBackgroundFile(file) {
  const dataUrl = await fileToDataUrl(file);
  const item = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    name: file.name || "background",
    dataUrl,
    updatedAt: Date.now(),
  };
  await backgroundStore("readwrite", (store) => store.put(item)).catch(() => {});
  savedBackgrounds = [item, ...savedBackgrounds.filter((bg) => bg.id !== item.id)];
  preferNoBackground = false;
  await setActiveBackground(item);
  renderBackgroundStrip();
}

async function setActiveBackground(item) {
  preferNoBackground = !item;
  activeBackground = item
    ? { ...item, image: await loadImage(item.dataUrl).catch(() => null) }
    : null;
}

async function removeSavedBackground(id) {
  await backgroundStore("readwrite", (store) => store.delete(id)).catch(() => {});
  savedBackgrounds = savedBackgrounds.filter((bg) => bg.id !== id);
  if (activeBackground?.id === id) {
    await setActiveBackground(savedBackgrounds[0] ?? null);
  }
  renderBackgroundStrip();
}

function renderBackgroundStrip() {
  backgroundStripEl.replaceChildren();
  const none = document.createElement("button");
  none.type = "button";
  none.className = "background-none" + (!activeBackground ? " active" : "");
  none.textContent = t("noBackground");
  none.addEventListener("click", async () => {
    await setActiveBackground(null);
    renderBackgroundStrip();
  });
  backgroundStripEl.appendChild(none);

  for (const bg of savedBackgrounds) {
    const item = document.createElement("button");
    item.type = "button";
    item.className = "background-thumb" + (activeBackground?.id === bg.id ? " active" : "");
    item.title = bg.name;
    item.style.backgroundImage = `url("${bg.dataUrl}")`;
    item.addEventListener("click", async () => {
      await setActiveBackground(bg);
      renderBackgroundStrip();
    });
    const remove = document.createElement("span");
    remove.className = "background-remove";
    remove.textContent = "-";
    remove.title = t("removeSavedBackground");
    remove.addEventListener("click", (e) => {
      e.stopPropagation();
      removeSavedBackground(bg.id);
    });
    item.appendChild(remove);
    backgroundStripEl.appendChild(item);
  }

  const add = document.createElement("button");
  add.type = "button";
  add.className = "background-add";
  add.textContent = "+";
  add.title = t("addBackground");
  add.addEventListener("click", () => backgroundInputEl.click());
  backgroundStripEl.appendChild(add);
}

function renderItemStrip() {
  itemStripEl.replaceChildren();
  for (const item of editorItems) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "item-thumb" + (selectedItemId === item.id ? " active" : "");
    btn.title = item.name;
    btn.style.backgroundImage = `url("${item.dataUrls[0]}")`;
    btn.addEventListener("click", () => {
      selectedItemId = item.id;
      renderItemStrip();
      drawPreviewFrame();
    });
    const remove = document.createElement("span");
    remove.className = "item-remove";
    remove.textContent = "-";
    remove.title = t("removeItem");
    remove.addEventListener("click", (e) => {
      e.stopPropagation();
      removeEditorItem(item.id);
    });
    btn.appendChild(remove);
    itemStripEl.appendChild(btn);
  }

  const add = document.createElement("button");
  add.type = "button";
  add.className = "item-add";
  add.textContent = "+";
  add.title = t("addItem");
  add.addEventListener("click", () => itemInputEl.click());
  itemStripEl.appendChild(add);
}

function itemRecord(item) {
  return {
    id: item.id,
    name: item.name,
    dataUrls: item.dataUrls,
    xRatio: item.xRatio,
    yRatio: item.yRatio,
    scaleRatio: item.scaleRatio,
    rotation: item.rotation || 0,
    hasKeyableBackground: item.hasKeyableBackground,
    updatedAt: Date.now(),
  };
}

async function persistEditorItems() {
  const records = editorItems.map(itemRecord);
  await itemStore("readwrite", (store) => {
    store.clear();
    for (const record of records) store.put(record);
  }).catch(() => {});
}

async function loadSavedItems() {
  const records = await itemStore("readonly", (store) => {
    const req = store.getAll();
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result ?? []);
      req.onerror = () => reject(req.error);
    });
  }).catch(() => []);
  records.sort((a, b) => (a.updatedAt ?? 0) - (b.updatedAt ?? 0));
  editorItems = [];
  for (const record of records) {
    const dataUrls = Array.isArray(record.dataUrls) ? record.dataUrls : [];
    const images = await Promise.all(dataUrls.map((url) => loadImage(url).catch(() => null)));
    if (!images.some(Boolean)) continue;
    editorItems.push({
      id: record.id,
      name: record.name || "item",
      dataUrls,
      images,
      hasKeyableBackground: Boolean(record.hasKeyableBackground) || images.some((img) => looksLikeKeyableImage(img)),
      xRatio: Number.isFinite(record.xRatio) ? record.xRatio : 0.5,
      yRatio: Number.isFinite(record.yRatio) ? record.yRatio : 0.5,
      scaleRatio: Number.isFinite(record.scaleRatio) ? record.scaleRatio : 0.24,
      rotation: Number.isFinite(record.rotation) ? record.rotation : 0,
    });
  }
  selectedItemId = editorItems.at(-1)?.id ?? null;
  renderItemStrip();
}

function removeEditorItem(id) {
  editorItems = editorItems.filter((item) => item.id !== id);
  if (selectedItemId === id) selectedItemId = editorItems.at(-1)?.id ?? null;
  renderItemStrip();
  updateKeyBackgroundVisibility();
  persistEditorItems();
  drawPreviewFrame();
}

async function createEditorItem(files) {
  const sorted = sortFilesByName(files).filter(isImageFile);
  if (!sorted.length) return;
  const dataUrls = await Promise.all(sorted.map(fileToDataUrl));
  const images = await Promise.all(dataUrls.map((url) => loadImage(url).catch(() => null)));
  const first = images.find(Boolean);
  if (!first) return;
  const item = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    name: sorted.length > 1 ? sorted[0].name.replace(/\d+\D*$/, "") || sorted[0].name : sorted[0].name,
    dataUrls,
    images,
    hasKeyableBackground: images.some((img) => looksLikeKeyableImage(img)),
    xRatio: 0.5,
    yRatio: 0.5,
    scaleRatio: 0.24,
    rotation: 0,
  };
  editorItems.push(item);
  selectedItemId = item.id;
  renderItemStrip();
  updateKeyBackgroundVisibility();
  persistEditorItems();
  drawPreviewFrame();
}

async function addEditorItemFiles(files) {
  const list = sortFilesByName([...files].filter(isImageFile));
  if (!list.length) return;
  const hasGif = list.some((file) => /\.gif$/i.test(file.name) || /image\/gif/i.test(file.type));
  if (list.length > 1 && !hasGif) {
    await createEditorItem(list);
    return;
  }
  for (const file of list) {
    await createEditorItem([file]);
  }
}

function selectedFrameIndexes() {
  if (!previewState) return [];
  return [...previewState.selectedFrames].sort((a, b) => a - b);
}

function previewFrameCount() {
  return previewState?.frameCount ?? previewState?.sequence.frames.length ?? 0;
}

function evenFrameIndexes(total, count) {
  if (total <= 0) return [];
  if (count >= total) return Array.from({ length: total }, (_, i) => i);
  if (count <= 1) return [0];
  const result = [];
  for (let i = 0; i < count; i++) {
    result.push(Math.min(total - 1, Math.round((i * (total - 1)) / (count - 1))));
  }
  return [...new Set(result)];
}

function updateFrameLabels() {
  if (!previewState) return;
  const count = previewState.selectedFrames.size;
  frameCountLabelEl.textContent = `${count}/${previewFrameCount()}`;
  frameCurrentLabelEl.textContent = t("totalFrames");
  frameSliderValueEl.textContent = String(count);
  frameCountSliderEl.value = String(Math.max(2, count));
}

function renderFrameList() {
  if (!previewState) return;
  frameListEl.replaceChildren();
  const total = previewFrameCount();
  for (let index = 0; index < total; index++) {
    const frame = sourceFrameName(previewState.sequence, index);
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "frame-thumb" + (previewState.selectedFrames.has(index) ? "" : " disabled");
    btn.title = `${index + 1}. ${frame}`;
    const img = document.createElement("img");
    img.alt = "";
    img.loading = "lazy";
    img.src = mediaUrl(previewState.sequence.relDir, previewState.sequence.frames[Math.min(index, previewState.sequence.frames.length - 1)]);
    const label = document.createElement("span");
    label.textContent = String(index + 1);
    const check = document.createElement("span");
    check.className = "frame-check";
    check.textContent = "✓";
    btn.appendChild(img);
    btn.appendChild(label);
    btn.appendChild(check);
    btn.addEventListener("click", () => {
      if (previewState.selectedFrames.has(index) && previewState.selectedFrames.size > 1) {
        previewState.selectedFrames.delete(index);
      } else {
        previewState.selectedFrames.add(index);
      }
      updateFrameLabels();
      renderFrameList();
    });
    frameListEl.appendChild(btn);
  }
  updateFrameLabels();
}

function resizePreviewCanvas() {
  if (!previewCanvasEl) return;
  const rect = previewCanvasEl.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  const w = Math.max(1, Math.round(rect.width * dpr));
  const h = Math.max(1, Math.round(rect.height * dpr));
  if (previewCanvasEl.width !== w || previewCanvasEl.height !== h) {
    previewCanvasEl.width = w;
    previewCanvasEl.height = h;
    applyPreviewTransform();
  }
}

function containRect(containerW, containerH, imgW, imgH) {
  if (!imgW || !imgH) return { x: 0, y: 0, w: containerW, h: containerH, scale: 1 };
  const scale = Math.min(containerW / imgW, containerH / imgH);
  const w = imgW * scale;
  const h = imgH * scale;
  return { x: (containerW - w) / 2, y: (containerH - h) / 2, w, h, scale };
}

function previewFrameSourceSize() {
  const sheet = previewState?.sheet;
  if (sheet) return { w: sheet.cellW, h: sheet.cellH };
  const img = previewState?.images?.find(Boolean);
  return { w: img?.width || 1, h: img?.height || 1 };
}

function previewTransformBasis() {
  if (!previewState) {
    return { x: 0, y: 0, w: previewCanvasEl.width || 1, h: previewCanvasEl.height || 1, base: 100 };
  }
  const w = previewCanvasEl.width || 1;
  const h = previewCanvasEl.height || 1;
  if (activeBackground?.image) {
    const rect = containRect(w, h, activeBackground.image.width, activeBackground.image.height);
    return { ...rect, base: rect.scale * 100 };
  }
  const src = previewFrameSourceSize();
  const rect = containRect(w, h, src.w, src.h);
  return { ...rect, base: rect.scale * 100 };
}

function applyPreviewTransform() {
  if (!previewState) return;
  const basis = previewTransformBasis();
  previewState.x = basis.x + basis.w * previewTransform.bgXRatio;
  previewState.y = basis.y + basis.h * previewTransform.bgYRatio;
  previewState.scale = Math.max(1, previewTransform.bgScaleRatio * basis.base);
  scaleValueEl.value = String(Math.round(previewState.scale));
  effectScaleEl.value = String(Math.min(100, Math.round(previewState.scale)));
}

function drawCheckerboard(ctx, w, h) {
  const size = 32 * (window.devicePixelRatio || 1);
  ctx.fillStyle = "#171717";
  ctx.fillRect(0, 0, w, h);
  for (let y = 0; y < h; y += size) {
    for (let x = 0; x < w; x += size) {
      ctx.fillStyle = ((x / size + y / size) % 2 === 0) ? "#242424" : "#1b1b1b";
      ctx.fillRect(x, y, size, size);
    }
  }
}

function drawKeyedImage(ctx, img, sx, sy, sw, sh, dx, dy, dw, dh, { key = false } = {}) {
  const keyBackground = key && keyBackgroundEl?.checked;
  if (!keyBackground) {
    ctx.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
    return;
  }
  const tmp = document.createElement("canvas");
  tmp.width = Math.max(1, Math.round(sw));
  tmp.height = Math.max(1, Math.round(sh));
  const tctx = tmp.getContext("2d");
  tctx.drawImage(img, sx, sy, sw, sh, 0, 0, tmp.width, tmp.height);
  const data = tctx.getImageData(0, 0, tmp.width, tmp.height);
  const px = data.data;
  for (let i = 0; i < px.length; i += 4) {
    const r = px[i], g = px[i + 1], b = px[i + 2];
    const black = r < 34 && g < 34 && b < 34;
    const green = g > 90 && g > r * 1.45 && g > b * 1.45;
    if (black || green) px[i + 3] = 0;
  }
  tctx.putImageData(data, 0, 0);
  ctx.drawImage(tmp, dx, dy, dw, dh);
}

function itemImage(item) {
  if (!item?.images?.length) return null;
  if (item.images.length === 1) return item.images[0];
  const frameMs = 1000 / globalFps();
  const index = Math.floor(performance.now() / frameMs) % item.images.length;
  return item.images[index];
}

function itemGeometry(item) {
  const img = itemImage(item);
  if (!img) return null;
  const basis = previewTransformBasis();
  const cx = basis.x + basis.w * item.xRatio;
  const cy = basis.y + basis.h * item.yRatio;
  const w = Math.max(8, basis.w * item.scaleRatio);
  const h = Math.max(8, w * (img.height / img.width));
  return { img, cx, cy, w, h, rotation: item.rotation || 0 };
}

function rotatedPoint(cx, cy, x, y, rotation) {
  const cos = Math.cos(rotation);
  const sin = Math.sin(rotation);
  return {
    x: cx + x * cos - y * sin,
    y: cy + x * sin + y * cos,
  };
}

function itemControlPoints(geom) {
  const hw = geom.w / 2;
  const hh = geom.h / 2;
  return {
    nw: rotatedPoint(geom.cx, geom.cy, -hw, -hh, geom.rotation),
    ne: rotatedPoint(geom.cx, geom.cy, hw, -hh, geom.rotation),
    se: rotatedPoint(geom.cx, geom.cy, hw, hh, geom.rotation),
    sw: rotatedPoint(geom.cx, geom.cy, -hw, hh, geom.rotation),
    rotate: rotatedPoint(geom.cx, geom.cy, 0, -hh - 32, geom.rotation),
    close: rotatedPoint(geom.cx, geom.cy, hw + 16, -hh - 16, geom.rotation),
  };
}

function drawEditorItem(ctx, item) {
  const geom = itemGeometry(item);
  if (!geom?.img) return;
  ctx.save();
  ctx.translate(geom.cx, geom.cy);
  ctx.rotate(geom.rotation);
  drawKeyedImage(ctx, geom.img, 0, 0, geom.img.width, geom.img.height, -geom.w / 2, -geom.h / 2, geom.w, geom.h, { key: false });
  ctx.restore();
  if (item.id !== selectedItemId) return;

  const pts = itemControlPoints(geom);
  const corners = [pts.nw, pts.ne, pts.se, pts.sw];
  ctx.save();
  ctx.strokeStyle = "rgba(201, 162, 39, 0.95)";
  ctx.lineWidth = 1.5 * (window.devicePixelRatio || 1);
  ctx.beginPath();
  ctx.moveTo(pts.nw.x, pts.nw.y);
  ctx.lineTo(pts.ne.x, pts.ne.y);
  ctx.lineTo(pts.se.x, pts.se.y);
  ctx.lineTo(pts.sw.x, pts.sw.y);
  ctx.closePath();
  ctx.stroke();

  const r = 6 * (window.devicePixelRatio || 1);
  ctx.fillStyle = "#101010";
  ctx.strokeStyle = "rgba(201, 162, 39, 0.95)";
  for (const pt of corners) {
    ctx.beginPath();
    ctx.rect(pt.x - r, pt.y - r, r * 2, r * 2);
    ctx.fill();
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(rotatedPoint(geom.cx, geom.cy, 0, -geom.h / 2, geom.rotation).x, rotatedPoint(geom.cx, geom.cy, 0, -geom.h / 2, geom.rotation).y);
  ctx.lineTo(pts.rotate.x, pts.rotate.y);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(pts.rotate.x, pts.rotate.y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = "rgba(80, 20, 20, 0.95)";
  ctx.strokeStyle = "rgba(255, 120, 120, 0.9)";
  ctx.beginPath();
  ctx.arc(pts.close.x, pts.close.y, r * 1.15, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = "#ffb0b0";
  ctx.beginPath();
  ctx.moveTo(pts.close.x - r * 0.45, pts.close.y - r * 0.45);
  ctx.lineTo(pts.close.x + r * 0.45, pts.close.y + r * 0.45);
  ctx.moveTo(pts.close.x + r * 0.45, pts.close.y - r * 0.45);
  ctx.lineTo(pts.close.x - r * 0.45, pts.close.y + r * 0.45);
  ctx.stroke();
  ctx.restore();
}

function distance(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function hitTestItem(point) {
  const dpr = window.devicePixelRatio || 1;
  const handleRadius = 14 * dpr;
  for (const item of [...editorItems].reverse()) {
    const geom = itemGeometry(item);
    if (!geom) continue;
    const pts = itemControlPoints(geom);
    if (distance(point, pts.close) <= handleRadius) return { item, mode: "delete" };
    if (distance(point, pts.rotate) <= handleRadius) return { item, mode: "rotate" };
    for (const pt of [pts.nw, pts.ne, pts.se, pts.sw]) {
      if (distance(point, pt) <= handleRadius) return { item, mode: "scale" };
    }
    const dx = point.x - geom.cx;
    const dy = point.y - geom.cy;
    const cos = Math.cos(-geom.rotation);
    const sin = Math.sin(-geom.rotation);
    const localX = dx * cos - dy * sin;
    const localY = dx * sin + dy * cos;
    if (Math.abs(localX) <= geom.w / 2 && Math.abs(localY) <= geom.h / 2) {
      return { item, mode: "move" };
    }
  }
  return null;
}

function canvasPointFromEvent(e) {
  const rect = previewCanvasEl.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  return {
    x: (e.clientX - rect.left) * dpr,
    y: (e.clientY - rect.top) * dpr,
  };
}

function setItemCenterFromPoint(item, point, offsetX = 0, offsetY = 0) {
  const basis = previewTransformBasis();
  item.xRatio = basis.w ? (point.x - offsetX - basis.x) / basis.w : 0.5;
  item.yRatio = basis.h ? (point.y - offsetY - basis.y) / basis.h : 0.5;
}

function drawPreviewFrame() {
  if (!previewState) return;
  resizePreviewCanvas();
  const ctx = previewCanvasEl.getContext("2d");
  const w = previewCanvasEl.width;
  const h = previewCanvasEl.height;
  ctx.clearRect(0, 0, w, h);
  drawCheckerboard(ctx, w, h);

  if (activeBackground?.image) {
    const img = activeBackground.image;
    const rect = containRect(w, h, img.width, img.height);
    ctx.drawImage(img, rect.x, rect.y, rect.w, rect.h);
  }

  for (const item of editorItems) {
    drawEditorItem(ctx, item);
  }

  const indexes = selectedFrameIndexes();
  if (indexes.length === 0) return;
  const idx = indexes[previewState.playIndex % indexes.length];
  const img = previewState.images[idx];
  if (!img) return;
  const scale = previewState.scale / 100;
  const sheet = previewState.sheet;
  const srcW = sheet ? sheet.cellW : img.width;
  const srcH = sheet ? sheet.cellH : img.height;
  const drawW = srcW * scale;
  const drawH = srcH * scale;
  if (sheet) {
    const col = idx % sheet.cols;
    const row = Math.floor(idx / sheet.cols);
    drawKeyedImage(
      ctx,
      img,
      col * sheet.cellW,
      row * sheet.cellH,
      sheet.cellW,
      sheet.cellH,
      previewState.x - drawW / 2,
      previewState.y - drawH / 2,
      drawW,
      drawH,
      { key: true }
    );
  } else {
    drawKeyedImage(ctx, img, 0, 0, img.width, img.height, previewState.x - drawW / 2, previewState.y - drawH / 2, drawW, drawH, { key: true });
  }
}

function previewTick(now) {
  if (!previewState) return;
  const indexes = selectedFrameIndexes();
  if (!previewState.lastTime) previewState.lastTime = now;
  const dt = now - previewState.lastTime;
  previewState.lastTime = now;
  previewState.accum += dt;
  const frameMs = 1000 / globalFps();
  while (indexes.length && previewState.accum >= frameMs) {
    previewState.accum -= frameMs;
    previewState.playIndex = (previewState.playIndex + 1) % indexes.length;
  }
  drawPreviewFrame();
  previewState.rafId = requestAnimationFrame(previewTick);
}

async function openPreviewEditor(sequence) {
  if (previewState?.rafId) cancelAnimationFrame(previewState.rafId);
  previewState = null;
  await loadSavedBackgrounds();
  previewTitleEl.textContent = sequence.effect || sequence.label || "VFX";
  previewSubtitleEl.textContent = sequence.id;
  previewModalEl.classList.remove("hidden");
  document.body.classList.add("preview-open");
  setPreviewWidth(previewModalEl.getBoundingClientRect().width || 620);

  const images = await Promise.all(
    sequence.frames.map((frame) => loadImage(mediaUrl(sequence.relDir, frame)).catch(() => null))
  );
  const sheet = isGif(sequence) ? spriteSheetLayout(images[0]) : null;
  const frameCount = sheet?.count ?? sequence.frames.length;
  resizePreviewCanvas();
  const minFrames = Math.min(2, Math.max(1, frameCount));
  frameCountSliderEl.min = String(minFrames);
  frameCountSliderEl.max = String(Math.max(minFrames, frameCount));
  frameCountSliderEl.value = String(Math.max(minFrames, frameCount));
  frameCountSliderEl.disabled = frameCount <= 1;
  frameSliderMaxEl.textContent = String(frameCount);

  const rect = previewCanvasEl.getBoundingClientRect();
  previewState = {
    sequence,
    images,
    sheet,
    frameCount,
    selectedFrames: new Set(Array.from({ length: frameCount }, (_, i) => i)),
    scale: 100,
    x: previewCanvasEl.width / 2,
    y: previewCanvasEl.height / 2,
    playIndex: 0,
    accum: 0,
    lastTime: 0,
    rafId: null,
    dragging: false,
  };
  applyPreviewTransform();
  if (selectedItemId && !editorItems.some((item) => item.id === selectedItemId)) {
    selectedItemId = editorItems.at(-1)?.id ?? null;
  }
  updateKeyBackgroundVisibility();
  renderItemStrip();
  renderBackgroundStrip();
  renderFrameList();
  previewState.rafId = requestAnimationFrame(previewTick);
}

function closePreviewEditor() {
  if (previewState?.rafId) cancelAnimationFrame(previewState.rafId);
  previewState = null;
  previewModalEl?.classList.add("hidden");
  document.body.classList.remove("preview-open");
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function safeExportName(value) {
  return (value || "vfx_spritesheet").replace(/[\\/:*?"<>|]+/g, "_").trim() || "vfx_spritesheet";
}

function defaultExportName() {
  return safeExportName(previewState?.sequence?.label || previewState?.sequence?.effect || "vfx_spritesheet");
}

async function writeFileWithSavePicker(blob, suggestedName, types) {
  if (!window.showSaveFilePicker) {
    downloadBlob(blob, suggestedName);
    return;
  }
  const handle = await window.showSaveFilePicker({
    id: "vfx-spritesheet-export",
    suggestedName,
    types,
  });
  const writable = await handle.createWritable();
  await writable.write(blob);
  await writable.close();
}

async function exportEditedSequence() {
  if (!previewState) return;
  const indexes = selectedFrameIndexes();
  if (!indexes.length) return;
  const scale = exportScaleMode === "original" ? 1 : previewState.scale / 100;
  const usedImages = previewState.sheet
    ? [previewState.images[0]].filter(Boolean)
    : indexes.map((idx) => previewState.images[idx]).filter(Boolean);
  const srcW = previewState.sheet?.cellW ?? Math.max(...usedImages.map((img) => img.width));
  const srcH = previewState.sheet?.cellH ?? Math.max(...usedImages.map((img) => img.height));
  const cellW = Math.max(1, Math.ceil(srcW * scale));
  const cellH = Math.max(1, Math.ceil(srcH * scale));
  const cols = Math.ceil(Math.sqrt(indexes.length));
  const rows = Math.ceil(indexes.length / cols);
  const canvas = document.createElement("canvas");
  canvas.width = cols * cellW;
  canvas.height = rows * cellH;
  const ctx = canvas.getContext("2d");
  const frames = [];

  indexes.forEach((sourceIndex, outputIndex) => {
    const img = previewState.images[sourceIndex];
    const drawImg = previewState.sheet ? previewState.images[0] : img;
    if (!drawImg) return;
    const col = outputIndex % cols;
    const row = Math.floor(outputIndex / cols);
    const w = cellW;
    const h = cellH;
    const x = col * cellW + Math.floor((cellW - w) / 2);
    const y = row * cellH + Math.floor((cellH - h) / 2);
    if (previewState.sheet) {
      const sourceCol = sourceIndex % previewState.sheet.cols;
      const sourceRow = Math.floor(sourceIndex / previewState.sheet.cols);
      ctx.drawImage(
        drawImg,
        sourceCol * previewState.sheet.cellW,
        sourceRow * previewState.sheet.cellH,
        previewState.sheet.cellW,
        previewState.sheet.cellH,
        x,
        y,
        w,
        h
      );
    } else {
      ctx.drawImage(drawImg, x, y, w, h);
    }
    frames.push({
      name: sourceFrameName(previewState.sequence, sourceIndex),
      sourceIndex,
      frame: { x, y, w, h },
      cell: { x: col * cellW, y: row * cellH, w: cellW, h: cellH },
      durationMs: Math.round(1000 / globalFps()),
    });
  });

  const pngBlob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
  const name = defaultExportName();
  const json = {
    meta: {
      image: `${name}.png`,
      source: previewState.sequence.id,
      fps: globalFps(),
      scale: previewState.scale / 100,
      frameCount: frames.length,
      size: { w: canvas.width, h: canvas.height },
      cell: { w: cellW, h: cellH },
    },
    frames,
  };
  const jsonBlob = new Blob([JSON.stringify(json, null, 2)], { type: "application/json" });

  await writeFileWithSavePicker(pngBlob, `${name}.png`, [
    { description: "PNG Image", accept: { "image/png": [".png"] } },
  ]);
  await writeFileWithSavePicker(jsonBlob, `${name}.json`, [
    { description: "JSON Metadata", accept: { "application/json": [".json"] } },
  ]);

}

async function openFolder(sequence) {
  try {
    const res = await fetch("/api/open-folder", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        relDir: sequence.relDir,
        poster: sequence.poster,
      }),
    });
    if (!res.ok) {
      const payload = await res.json().catch(() => ({}));
      throw new Error(payload.error || `HTTP ${res.status}`);
    }
    syncStatusEl.textContent = t("openedFolder");
  } catch {
    syncStatusEl.textContent = t("openFolderFailed");
  }
}

async function addToTrash(id) {
  const previousScrollTop = currentScrollTop();
  await fetch("/api/user-state", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ addTrashId: id }),
  });
  const res = await fetch("/api/user-state");
  userState = await res.json();
  applyFilters();
  restoreScrollAfterRender(previousScrollTop);
}

async function removeFromTrash(id) {
  const previousScrollTop = currentScrollTop();
  await fetch("/api/user-state", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ removeTrashId: id }),
  });
  const res = await fetch("/api/user-state");
  userState = await res.json();
  applyFilters();
  restoreScrollAfterRender(previousScrollTop);
}

function matchesTags(sequence) {
  const colors = sequence.tags?.colors ?? [];
  const functions = sequence.tags?.functions ?? [];

  if (selectedColors.size > 0) {
    if (!colors.some((c) => selectedColors.has(c))) return false;
  }
  if (selectedFunctions.size > 0) {
    if (!functions.some((f) => selectedFunctions.has(f))) return false;
  }
  return true;
}

function applyFilters() {
  if (!catalog) return;

  const q = searchEl.value.trim().toLowerCase();
  const ver = versionFilterEl.value;

  let pool;
  if (viewMode === "trash") {
    pool = trashPool();
  } else {
    pool = catalog.sequences ?? [];
    pool = pool.filter((s) => !isInTrash(s));
  }

  filtered = pool.filter((s) => {
    if (ver && s.version !== ver) return false;
    if (!folderMatches(s)) return false;
    if (!matchesTags(s)) return false;
    if (!q) return true;
    const hay = `${s.effect} ${s.relDir} ${s.label || ""} ${s.id}`.toLowerCase();
    return hay.includes(q);
  });

  statusEl.textContent = `${filtered.length} ${t("itemCount")}${
    viewMode === "trash" ? ` (${t("trashDuplicates")})` : ""
  }`;
  renderGrid();
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#039;",
  }[char]));
}

function childFolders(parent) {
  const folders = catalog?.folders ?? [];
  const prefix = parent ? `${parent}/` : "";
  const children = new Map();

  for (const folder of folders) {
    if (folder === parent) continue;
    if (!folder.startsWith(prefix)) continue;
    const rest = folder.slice(prefix.length);
    if (!rest || rest.includes("/")) continue;
    children.set(folder, rest);
  }

  return [...children.entries()].sort((a, b) => naturalCompare(a[1], b[1]));
}

function itemCountForFolder(folder) {
  const pool = viewMode === "trash" ? trashPool() : catalog?.sequences ?? [];
  return pool.filter((s) => {
    if (viewMode !== "trash" && isInTrash(s)) return false;
    if (!folder) return true;
    return s.relDir === folder || s.relDir.startsWith(`${folder}/`);
  }).length;
}

function renderFolderBranch(parent, depth = 0) {
  for (const [folder, name] of childFolders(parent)) {
    const children = childFolders(folder);
    const hasChildren = children.length > 0;
    const expanded = expandedFolders.has(folder);
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className =
      "folder-node" +
      (selectedFolder === folder ? " active" : "") +
      (hasChildren ? " has-children" : "");
    btn.style.setProperty("--depth", depth);
    btn.title = folder;
    btn.innerHTML = `<span class="folder-icon">${hasChildren ? (expanded ? "▾" : "▸") : ""}</span><span class="folder-name">${escapeHtml(name)}</span><span class="folder-count">${itemCountForFolder(folder)}</span>`;
    btn.addEventListener("click", () => {
      selectedFolder = folder;
      if (hasChildren) {
        if (expandedFolders.has(folder)) expandedFolders.delete(folder);
        else expandedFolders.add(folder);
      }
      renderFolderTree();
      applyFilters();
    });
    folderTreeEl.appendChild(btn);
    if (hasChildren && expanded) {
      renderFolderBranch(folder, depth + 1);
    }
  }
}

function renderFolderTree() {
  if (!folderTreeEl) return;
  folderTreeEl.replaceChildren();

  const rootBtn = document.createElement("button");
  rootBtn.type = "button";
  rootBtn.className = "folder-node root" + (selectedFolder === "" ? " active" : "");
  rootBtn.style.setProperty("--depth", 0);
  rootBtn.innerHTML = `<span class="folder-icon">▾</span><span class="folder-name">VFX</span><span class="folder-count">${itemCountForFolder("")}</span>`;
  rootBtn.addEventListener("click", () => {
    selectedFolder = "";
    renderFolderTree();
    applyFilters();
  });
  folderTreeEl.appendChild(rootBtn);
  renderFolderBranch("", 1);
}

function createCardShell(sequence) {
  const card = document.createElement("article");
  card.className = "card";
  card.dataset.id = sequence.id;

  const wrap = document.createElement("div");
  wrap.tabIndex = 0;
  wrap.setAttribute("role", "button");
  wrap.className = "card-canvas-wrap";
  wrap.title = t("openPreview");
  wrap.addEventListener("click", () => openPreviewEditor(sequence));
  wrap.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      openPreviewEditor(sequence);
    }
  });

  if (viewMode === "trash" && isInTrash(sequence)) {
    const restoreBtn = document.createElement("button");
    restoreBtn.type = "button";
    restoreBtn.className = "card-restore-btn";
    restoreBtn.textContent = t("restore");
    restoreBtn.title = t("restoreTitle");
    restoreBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      removeFromTrash(sequence.id);
    });
    wrap.appendChild(restoreBtn);
  } else if (viewMode !== "trash") {
    const trashBtn = document.createElement("button");
    trashBtn.type = "button";
    trashBtn.className = "card-trash-btn";
    trashBtn.textContent = "−";
    trashBtn.title = t("moveTrash");
    trashBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      addToTrash(sequence.id);
    });
    wrap.appendChild(trashBtn);
  }

  const poster = document.createElement("img");
  poster.className = "card-poster";
  poster.alt = "";
  poster.loading = "lazy";
  poster.src = mediaUrl(sequence.relDir, sequence.poster);
  wrap.appendChild(poster);

  const canvasSlot = document.createElement("div");
  canvasSlot.className = "card-canvas-slot hidden";
  wrap.appendChild(canvasSlot);

  const ver = document.createElement("span");
  ver.className = "card-version";
  ver.textContent = sequence.version;
  wrap.appendChild(ver);

  const badge = document.createElement("span");
  badge.className = "card-badge";
  badge.textContent = isGif(sequence) ? "GIF" : `${sequence.frameCount} ${t("frames")}`;
  wrap.appendChild(badge);

  if (sequence.duplicateOf) {
    const dup = document.createElement("span");
    dup.className = "card-dup-badge";
    dup.textContent = t("duplicate");
    dup.title = t("duplicateOf").replace("{id}", sequence.duplicateOf);
    wrap.appendChild(dup);
  }

  const body = document.createElement("div");
  body.className = "card-body";
  const title = document.createElement("p");
  title.className = "card-title";
  title.textContent = sequence.effect;
  title.title = sequence.effect;
  const sub = document.createElement("p");
  sub.className = "card-sub";
  const subParts = [sequence.relDir.split("/").slice(2).join("/"), sequence.label]
    .filter(Boolean)
    .filter((v, i, a) => a.indexOf(v) === i);
  sub.textContent = subParts.join(" · ") || sequence.relDir;
  sub.title = sequence.id;
  const openBtn = document.createElement("button");
  openBtn.type = "button";
  openBtn.className = "card-open-btn";
  openBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    openFolder(sequence);
  });
  openBtn.textContent = t("openFolder");
  body.appendChild(title);
  body.appendChild(sub);
  body.appendChild(openBtn);

  card.appendChild(wrap);
  card.appendChild(body);

  return card;
}

function mountPlayer(rec) {
  if (rec.player) return;
  const slot = rec.card.querySelector(".card-canvas-slot");
  const poster = rec.card.querySelector(".card-poster");
  if (!slot) return;

  const canvas = document.createElement("canvas");
  canvas.width = 200;
  canvas.height = 200;
  slot.replaceChildren(canvas);
  slot.classList.remove("hidden");
  poster?.classList.add("hidden");

  const player = new SequencePlayer(canvas, rec.sequence, { fps: globalFps() });
  rec.player = player;
  player.load().then(() => {
    if (player.visible) player.play();
  });
}

function unmountPlayer(rec) {
  if (!rec.player) return;
  rec.player.destroy();
  rec.player = undefined;
  const slot = rec.card.querySelector(".card-canvas-slot");
  const poster = rec.card.querySelector(".card-poster");
  slot?.classList.add("hidden");
  slot?.replaceChildren();
  poster?.classList.remove("hidden");
}

function renderGrid() {
  cards.forEach((rec) => unmountPlayer(rec));
  cards.clear();
  observer.disconnect();
  gridEl.replaceChildren();
  renderedCount = 0;
  setCurrentScrollTop(0);
  renderMoreCards(INITIAL_RENDER_COUNT);
  requestAnimationFrame(loadMoreIfNeeded);
}

function renderMoreCards(count = RENDER_BATCH_SIZE) {
  if (renderedCount >= filtered.length) return;

  const frag = document.createDocumentFragment();
  const end = Math.min(filtered.length, renderedCount + count);
  for (const sequence of filtered.slice(renderedCount, end)) {
    const card = createCardShell(sequence);
    const rec = { card, sequence };
    cards.set(sequence.id, rec);
    frag.appendChild(card);
    observer.observe(card);
  }
  gridEl.appendChild(frag);
  renderedCount = end;
}

function loadMoreIfNeeded() {
  if (renderedCount >= filtered.length) return;
  const scrollTop = currentScrollTop();
  const clientHeight = currentClientHeight();
  const scrollHeight = currentScrollHeight();
  if (scrollTop + clientHeight >= scrollHeight - 900) {
    renderMoreCards();
    requestAnimationFrame(loadMoreIfNeeded);
  }
}

const observer = new IntersectionObserver(
  (entries) => {
    for (const entry of entries) {
      const id = entry.target.dataset.id;
      const rec = cards.get(id);
      if (!rec) continue;
      if (entry.isIntersecting) {
        mountPlayer(rec);
        if (rec.player) {
          rec.player.setVisible(true);
          if (rec.player.loaded) rec.player.play();
        }
      } else {
        if (rec.player) rec.player.setVisible(false);
        unmountPlayer(rec);
      }
    }
  },
  { root: null, rootMargin: "120px", threshold: 0.05 }
);

function renderChips(container, items, selectedSet, onToggle, group) {
  container.replaceChildren();
  for (const item of items) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "chip" + (selectedSet.has(item.id) ? " active" : "");
    btn.textContent = group ? tagText(group, item) : item.label;
    btn.dataset.id = item.id;
    btn.addEventListener("click", () => {
      if (selectedSet.has(item.id)) selectedSet.delete(item.id);
      else selectedSet.add(item.id);
      onToggle();
    });
    container.appendChild(btn);
  }
}

function renderTagBars() {
  const vocab = catalog?.tagVocabulary ?? { functions: [], colors: [] };

  renderChips(colorTagsEl, vocab.colors ?? [], selectedColors, () => {
    renderTagBars();
    applyFilters();
  }, "colors");

  renderChips(functionTagsEl, vocab.functions ?? [], selectedFunctions, () => {
    renderTagBars();
    applyFilters();
  }, "functions");

  viewTagsEl.replaceChildren();
  const allBtn = document.createElement("button");
  allBtn.type = "button";
  allBtn.className = "chip" + (viewMode === "all" ? " active" : "");
  allBtn.addEventListener("click", () => {
    viewMode = "all";
    renderTagBars();
    renderFolderTree();
    applyFilters();
  });
  allBtn.textContent = t("all");
  viewTagsEl.appendChild(allBtn);

  const trashBtn = document.createElement("button");
  trashBtn.type = "button";
  trashBtn.className =
    "chip chip-trash" + (viewMode === "trash" ? " active" : "");
  const trashCount = trashPool().length;
  trashBtn.textContent = `${t("trashDuplicates")} (${trashCount})`;
  trashBtn.addEventListener("click", () => {
    viewMode = "trash";
    renderTagBars();
    renderFolderTree();
    applyFilters();
  });
  viewTagsEl.appendChild(trashBtn);
}

async function loadCatalog() {
  const res = await fetch("/api/catalog");
  if (!res.ok) return false;
  catalog = await res.json();
  const now = new Date();
  syncStatusEl.textContent = `${t("sync")} ${now.toLocaleTimeString()}`;
  return true;
}

async function refreshCatalog() {
  const prevIds = new Set(filtered.map((s) => s.id));
  const prevCatalogIds = new Set(allSequences().map((s) => s.id));
  const previousScrollTop = currentScrollTop();
  const ok = await loadCatalog();
  if (!ok) return;
  const nextCatalogIds = new Set(allSequences().map((s) => s.id));
  const catalogUnchanged =
    prevCatalogIds.size === nextCatalogIds.size &&
    [...prevCatalogIds].every((id) => nextCatalogIds.has(id));
  if (catalogUnchanged) return;
  renderTagBars();
  renderFolderTree();
  applyFilters();
  if (previousScrollTop > 0) {
    restoreScrollAfterRender(previousScrollTop);
  }
  const nextIds = new Set(filtered.map((s) => s.id));
  for (const id of prevIds) {
    if (!nextIds.has(id)) {
      /* removed by sync */
    }
  }
}

async function init() {
  loadSavedFps();
  loadSavedLanguage();
  applySavedPreviewWidth();
  applySavedFolderWidth();
  await loadSavedItems();

  try {
    const stateRes = await fetch("/api/user-state");
    if (stateRes.ok) userState = await stateRes.json();
  } catch {
    /* ignore */
  }

  const ok = await loadCatalog();
  if (!ok) {
    emptyEl.classList.remove("hidden");
    return;
  }

  emptyEl.classList.add("hidden");
  gridEl.hidden = false;

  const versions = [...new Set((catalog.sequences ?? []).map((s) => s.version))].sort(naturalCompare);
  for (const v of versions) {
    const opt = document.createElement("option");
    opt.value = v;
    opt.textContent = v;
    versionFilterEl.appendChild(opt);
  }

  renderTagBars();
  renderFolderTree();

  searchEl.addEventListener("input", applyFilters);
  versionFilterEl.addEventListener("change", applyFilters);
  contentPanelEl?.addEventListener("scroll", loadMoreIfNeeded, { passive: true });
  window.addEventListener("scroll", loadMoreIfNeeded, { passive: true });
  globalFpsEl.addEventListener("change", () => applyFpsChange(globalFpsEl.value));
  previewCloseEl.addEventListener("click", closePreviewEditor);
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !previewModalEl.classList.contains("hidden")) {
      closePreviewEditor();
    }
  });
  backgroundInputEl.addEventListener("change", async () => {
    const file = backgroundInputEl.files?.[0];
    if (!file) return;
    await saveBackgroundFile(file);
    backgroundInputEl.value = "";
  });
  itemInputEl.addEventListener("change", async () => {
    const files = [...(itemInputEl.files ?? [])];
    await addEditorItemFiles(files);
    itemInputEl.value = "";
  });
  effectScaleEl.addEventListener("input", () => {
    if (!previewState) return;
    previewState.scale = Number(effectScaleEl.value) || 100;
    scaleValueEl.value = String(previewState.scale);
    rememberPreviewTransform();
  });
  scaleValueEl.addEventListener("change", () => {
    if (!previewState) return;
    const value = Math.max(1, Number(scaleValueEl.value) || 100);
    previewState.scale = value;
    scaleValueEl.value = String(value);
    effectScaleEl.value = String(Math.min(100, value));
    rememberPreviewTransform();
  });
  keyBackgroundEl.addEventListener("change", drawPreviewFrame);
  frameCountSliderEl.addEventListener("input", () => {
    if (!previewState) return;
    const total = previewFrameCount();
    const count = Number(frameCountSliderEl.value) || total;
    previewState.selectedFrames = new Set(evenFrameIndexes(total, count));
    previewState.playIndex = 0;
    renderFrameList();
  });
  previewCanvasEl.addEventListener("pointerdown", (e) => {
    if (!previewState) return;
    const point = canvasPointFromEvent(e);
    const hit = hitTestItem(point);
    if (hit) {
      selectedItemId = hit.item.id;
      renderItemStrip();
      drawPreviewFrame();
      if (hit.mode === "delete") {
        removeEditorItem(hit.item.id);
        return;
      }
      const geom = itemGeometry(hit.item);
      previewCanvasEl.setPointerCapture(e.pointerId);
      itemDrag = {
        id: hit.item.id,
        mode: hit.mode,
        startPoint: point,
        startScaleRatio: hit.item.scaleRatio,
        startRotation: hit.item.rotation || 0,
        startDistance: geom ? Math.max(1, distance(point, { x: geom.cx, y: geom.cy })) : 1,
        startAngle: geom ? Math.atan2(point.y - geom.cy, point.x - geom.cx) : 0,
        offsetX: geom ? point.x - geom.cx : 0,
        offsetY: geom ? point.y - geom.cy : 0,
      };
      return;
    }
    selectedItemId = null;
    renderItemStrip();
    previewState.dragging = true;
    previewCanvasEl.setPointerCapture(e.pointerId);
    previewState.dragOffsetX = point.x - previewState.x;
    previewState.dragOffsetY = point.y - previewState.y;
  });
  previewCanvasEl.addEventListener("pointermove", (e) => {
    if (itemDrag) {
      const item = editorItems.find((entry) => entry.id === itemDrag.id);
      if (!item) return;
      const point = canvasPointFromEvent(e);
      const geom = itemGeometry(item);
      if (!geom) return;
      if (itemDrag.mode === "move") {
        setItemCenterFromPoint(item, point, itemDrag.offsetX, itemDrag.offsetY);
      } else if (itemDrag.mode === "scale") {
        const currentDistance = Math.max(1, distance(point, { x: geom.cx, y: geom.cy }));
        item.scaleRatio = Math.max(0.02, itemDrag.startScaleRatio * (currentDistance / itemDrag.startDistance));
      } else if (itemDrag.mode === "rotate") {
        const angle = Math.atan2(point.y - geom.cy, point.x - geom.cx);
        item.rotation = itemDrag.startRotation + angle - itemDrag.startAngle;
      }
      drawPreviewFrame();
      return;
    }
    if (!previewState?.dragging) return;
    const point = canvasPointFromEvent(e);
    previewState.x = point.x - (previewState.dragOffsetX || 0);
    previewState.y = point.y - (previewState.dragOffsetY || 0);
    rememberPreviewTransform();
  });
  previewCanvasEl.addEventListener("pointerup", () => {
    if (itemDrag) persistEditorItems();
    itemDrag = null;
    if (previewState) previewState.dragging = false;
  });
  previewCanvasEl.addEventListener("pointercancel", () => {
    if (itemDrag) persistEditorItems();
    itemDrag = null;
    if (previewState) previewState.dragging = false;
  });
  previewResizerEl.addEventListener("pointerdown", (e) => {
    e.preventDefault();
    previewResizerEl.setPointerCapture(e.pointerId);
    const move = (event) => {
      const width = Math.min(window.innerWidth - 260, Math.max(360, window.innerWidth - event.clientX));
      setPreviewWidth(width);
      localStorage.setItem(PREVIEW_WIDTH_STORAGE_KEY, String(width));
    };
    const up = () => {
      previewResizerEl.removeEventListener("pointermove", move);
      previewResizerEl.removeEventListener("pointerup", up);
      previewResizerEl.removeEventListener("pointercancel", up);
    };
    previewResizerEl.addEventListener("pointermove", move);
    previewResizerEl.addEventListener("pointerup", up);
    previewResizerEl.addEventListener("pointercancel", up);
  });
  folderResizerEl.addEventListener("pointerdown", (e) => {
    e.preventDefault();
    folderResizerEl.setPointerCapture(e.pointerId);
    const move = (event) => setFolderWidth(event.clientX);
    const up = () => {
      folderResizerEl.removeEventListener("pointermove", move);
      folderResizerEl.removeEventListener("pointerup", up);
      folderResizerEl.removeEventListener("pointercancel", up);
    };
    folderResizerEl.addEventListener("pointermove", move);
    folderResizerEl.addEventListener("pointerup", up);
    folderResizerEl.addEventListener("pointercancel", up);
  });
  exportOriginalEl.addEventListener("click", async () => {
    if (!previewState) return;
    exportScaleMode = "original";
    await exportEditedSequence();
  });
  exportScaledEl.addEventListener("click", async () => {
    if (!previewState) return;
    exportScaleMode = "scaled";
    await exportEditedSequence();
  });
  settingsButtonEl.addEventListener("click", (e) => {
    e.stopPropagation();
    settingsMenuEl.classList.toggle("hidden");
    settingsButtonEl.setAttribute("aria-expanded", String(!settingsMenuEl.classList.contains("hidden")));
  });
  settingsMenuEl.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-lang]");
    if (!btn) return;
    applyLanguage(btn.dataset.lang);
    settingsMenuEl.classList.add("hidden");
    settingsButtonEl.setAttribute("aria-expanded", "false");
  });
  document.addEventListener("click", () => {
    settingsMenuEl.classList.add("hidden");
    settingsButtonEl.setAttribute("aria-expanded", "false");
  });

  applyFilters();

  setInterval(refreshCatalog, POLL_MS);
  window.addEventListener("focus", refreshCatalog);
}

init();

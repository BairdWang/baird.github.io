# SPINE VFX PNG 序列浏览器

在本地以动画形式浏览 `1000多套SPINE特效` 文件夹中的 PNG 序列帧。

## 要求

- [Node.js](https://nodejs.org/) 18+

## 快速开始

```bat
cd C:\Baird\Work\VFX\vfx-browser
npm install
npm run build
npm start
```

浏览器打开：<http://127.0.0.1:5173>  
或双击 **`start.bat`**（Windows）/ **`start.command`**（Mac）。

## 功能

- **网格预览**：滚动到可见区域自动播放
- **单击卡片**：在资源管理器中打开素材文件夹（并选中首帧 PNG）
- **分类标签**：顶部按颜色、功能筛选（如「红」+「闪电」）
- **Trash / 重复**：自动隐藏内容哈希重复的序列；hover 点「−」手动移入 Trash
- **自动同步**：每 30 秒及窗口重新聚焦时检查磁盘，已删除文件夹的条目会消失

## 环境变量

| 变量 | 默认值 |
|------|--------|
| `VFX_ROOT` | `C:\Baird\Work\VFX\1000多套SPINE特效` |
| `PORT` | `5173` |

## API（本地）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/catalog` | 索引 + 过滤已删除目录 |
| POST | `/api/open-folder` | `{ relDir, poster? }` 打开文件夹 |
| GET/PUT | `/api/user-state` | 手动 Trash 列表 `trashIds` |

## 索引与标签

```bat
npm run build
```

- 识别 `1.png`、时间码帧、`huo_buff_0000.png` 等序列命名
- 排除大型 Spine `images` 图集目录
- 为首帧计算 MD5，自动将重复项写入 `catalog.duplicates`
- 根据路径关键词 + 首帧颜色采样打标签

资源变更后请重新 `npm run build`。

## 文件

| 文件 | 说明 |
|------|------|
| `catalog.json` | 构建生成（勿手改） |
| `user-state.json` | 手动 Trash 记录（本地） |

import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);

export const TAG_VOCABULARY = {
  functions: [
    { id: "heal", label: "加血" },
    { id: "fire", label: "火焰" },
    { id: "ice", label: "冰冻" },
    { id: "poison", label: "毒" },
    { id: "explosion", label: "爆炸" },
    { id: "lightning", label: "闪电" },
    { id: "wind", label: "风" },
    { id: "holy", label: "光" },
    { id: "dark", label: "暗" },
    { id: "hit", label: "受击" },
    { id: "buff", label: "增益" },
    { id: "debuff", label: "减益" },
    { id: "ui", label: "UI" },
    { id: "other", label: "其他" },
  ],
  colors: [
    { id: "red", label: "红" },
    { id: "orange", label: "橙" },
    { id: "yellow", label: "黄" },
    { id: "green", label: "绿" },
    { id: "cyan", label: "青" },
    { id: "blue", label: "蓝" },
    { id: "purple", label: "紫" },
    { id: "pink", label: "粉" },
    { id: "white", label: "白" },
    { id: "gold", label: "金" },
    { id: "black", label: "黑" },
    { id: "multi", label: "多彩" },
  ],
};

const FUNCTION_KEYWORDS = {
  heal: [
    "加血", "治疗", "恢复", "回血", "补血", "生命", "heal", "hp", "xue", "buf", "cure", "recover", "life",
  ],
  fire: ["火", "huo", "burn", "flame", "yan", "fire", "molten", "ignite", "灼"],
  ice: ["冰", "bing", "frozen", "freeze", "frost", "ice", "cold", "寒"],
  poison: ["毒", "du", "poison", "toxic", "venom"],
  explosion: ["爆炸", "bao", "boom", "blast", "explod", "burst", "爆"],
  lightning: ["闪电", "雷", "lei", "dian", "shock", "lightning", "thunder", "电击", "电"],
  wind: ["风", "feng", "wind", "gale", "cyclone"],
  holy: ["圣", "光", "guang", "holy", "divine", "shine", "radiant", "神"],
  dark: ["暗", "dark", "shadow", "void", "curse", "魔", "邪"],
  hit: ["受击", "hit", "hurt", "damage", "strike", "impact", "打击", "击中", "critical", "crit"],
  buff: ["buff", "增益", "强化", "enhance", "powerup"],
  debuff: ["debuff", "减益", "虚弱", "减速", "眩晕", "stun", "slow"],
  ui: ["ui", "kapai", "界面", "段位", "排名", "paiming", "duanwei", "xuyuan", "juanzhou", "按钮", "button"],
};

const COLOR_KEYWORDS = {
  red: ["红", "hong", "red", "crimson", "朱"],
  orange: ["橙", "cheng", "orange"],
  yellow: ["黄", "huang", "yellow", "goldenglow"],
  green: ["绿", "lv", "green", "翠"],
  cyan: ["青", "qing", "cyan", "teal", "turquoise"],
  blue: ["蓝", "lan", "blue", "azure", "冰蓝"],
  purple: ["紫", "zi", "purple", "violet"],
  pink: ["粉", "fen", "pink", "magenta"],
  white: ["白", "bai", "white", "silver"],
  gold: ["金", "jin", "gold", "golden"],
  black: ["黑", "hei", "black"],
};

function matchKeywords(text, keywordMap) {
  const lower = text.toLowerCase();
  const matched = [];
  for (const [id, words] of Object.entries(keywordMap)) {
    if (words.some((w) => lower.includes(w.toLowerCase()))) {
      matched.push(id);
    }
  }
  return matched;
}

function rgbToHsl(r, g, b) {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
        break;
      case g:
        h = ((b - r) / d + 2) / 6;
        break;
      default:
        h = ((r - g) / d + 4) / 6;
    }
  }
  return { h: h * 360, s, l };
}

function rgbToColorTag(r, g, b, a = 255) {
  if (a < 48) return null;

  const { h, s, l } = rgbToHsl(r, g, b);
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);

  if (max < 42) return "black";
  if (l > 0.78 && s < 0.28) return "white";
  if (max - min < 18) return l > 0.68 ? "white" : null;
  if (r > 170 && g > 115 && b < 95 && h >= 32 && h < 58) return "gold";
  if (h < 15 || h >= 345) return "red";
  if (h < 38) return "orange";
  if (h < 54 && l < 0.72 && r > b * 1.5) return "gold";
  if (h < 70) return "yellow";
  if (h < 150) return "green";
  if (h < 190) return "cyan";
  if (h < 250) return "blue";
  if (h < 290) return "purple";
  if (h < 330) return "pink";
  return "red";
}

function colorWeight(r, g, b, a) {
  const { s, l } = rgbToHsl(r, g, b);
  const alpha = a / 255;
  const brightness = Math.max(r, g, b) / 255;
  return alpha * (0.25 + s) * (0.3 + brightness) * (0.65 + Math.min(l, 0.85));
}

let pngjsModule;

async function getPngjs() {
  if (pngjsModule !== undefined) return pngjsModule;
  try {
    pngjsModule = require("pngjs").PNG;
    return pngjsModule;
  } catch {
    pngjsModule = null;
    return null;
  }
}

function mergeColorStats(target, source) {
  for (const [tag, weight] of source) {
    target.set(tag, (target.get(tag) ?? 0) + weight);
  }
}

export async function sampleImageColors(absImagePath) {
  const PNG = await getPngjs();
  if (!PNG || !fs.existsSync(absImagePath)) return new Map();

  try {
    const buffer = fs.readFileSync(absImagePath);
    const png = PNG.sync.read(buffer, { checkCRC: false });
    const { width, height, data } = png;
    if (!width || !height) return new Map();

    const colors = new Map();
    const stepX = Math.max(1, Math.floor(width / 64));
    const stepY = Math.max(1, Math.floor(height / 64));

    for (let y = 0; y < height; y += stepY) {
      for (let x = 0; x < width; x += stepX) {
        const i = (width * y + x) << 2;
        const tag = rgbToColorTag(data[i], data[i + 1], data[i + 2], data[i + 3]);
        if (!tag) continue;
        const weight = colorWeight(data[i], data[i + 1], data[i + 2], data[i + 3]);
        colors.set(tag, (colors.get(tag) ?? 0) + weight);
      }
    }

    return colors;
  } catch {
    return new Map();
  }
}

export async function sampleSequenceColors(sequence, vfxRoot) {
  const absDir = path.join(vfxRoot, sequence.relDir);
  const frameCount = sequence.frames?.length ?? 0;
  const indices = new Set([0, Math.floor(frameCount / 2), frameCount - 1]);
  if (frameCount > 5) {
    indices.add(Math.floor(frameCount * 0.25));
    indices.add(Math.floor(frameCount * 0.75));
  }

  const totals = new Map();
  for (const index of indices) {
    const frame = sequence.frames?.[index];
    if (!frame) continue;
    mergeColorStats(totals, await sampleImageColors(path.join(absDir, frame)));
  }

  const entries = [...totals.entries()].sort((a, b) => b[1] - a[1]);
  const total = entries.reduce((sum, [, weight]) => sum + weight, 0);
  if (total <= 0) return [];

  const significant = entries.filter(([, weight], index) => {
    const share = weight / total;
    return share >= (index === 0 ? 0.16 : 0.11);
  });

  const colors = significant.slice(0, 3).map(([tag]) => tag);
  const colorful = significant.filter(([tag]) => tag !== "white" && tag !== "black");
  const colorfulWeight = colorful.reduce((sum, [, weight]) => sum + weight, 0);
  if (colorful.length >= 3 && colorfulWeight / total >= 0.55) {
    return ["multi", ...colors.filter((tag) => tag !== "multi").slice(0, 2)];
  }

  return colors;
}

export function classifyFunctions(sequence) {
  const text = `${sequence.effect} ${sequence.relDir} ${sequence.label || ""}`;
  const matched = matchKeywords(text, FUNCTION_KEYWORDS);
  if (matched.length === 0) return ["other"];
  return [...new Set(matched)];
}

export function classifyColorsFromText(sequence) {
  const text = `${sequence.effect} ${sequence.relDir} ${sequence.label || ""}`;
  return [...new Set(matchKeywords(text, COLOR_KEYWORDS))];
}

export async function classifySequenceTags(sequence, vfxRoot) {
  const fromText = classifyColorsFromText(sequence);
  const fromImage = await sampleSequenceColors(sequence, vfxRoot);
  const colors = [...new Set([...fromText, ...fromImage])];
  const functions = classifyFunctions(sequence);

  return { functions, colors };
}

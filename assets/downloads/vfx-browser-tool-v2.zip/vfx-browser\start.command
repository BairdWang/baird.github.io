#!/bin/bash
set -e
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js not found. Please install Node.js 18+ first."
  read -r -p "Press Enter to close..."
  exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
  echo "npm not found. Please make sure Node.js and npm are installed."
  read -r -p "Press Enter to close..."
  exit 1
fi

echo "Building catalog..."
npm run build

echo "Starting server..."
npm start >/tmp/vfx-browser.log 2>&1 &
SERVER_PID=$!

for _ in {1..50}; do
  if curl -fsS "http://127.0.0.1:5173" >/dev/null 2>&1; then
    break
  fi
  sleep 0.2
done

open "http://127.0.0.1:5173"
wait "$SERVER_PID"

import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import {
  TAG_VOCABULARY,
  classifySequenceTags,
} from "./classify-tags.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const OUT_DIR = path.join(__dirname, "..");
const DEFAULT_VFX_ROOT = path.resolve(OUT_DIR, "..");
const VFX_ROOT = path.resolve(process.env.VFX_ROOT || DEFAULT_VFX_ROOT);
const MAX_DEPTH = 12;
const EXCLUDED_TOP_LEVEL_DIRS = new Set(["sequence-viewer", "vfx-browser"]);

const FRAME_NUMERIC = /^\d+\.png$/i;
const FRAME_TIMECODE = /^\d+_\d+_\d+\.png$/i;
const FRAME_PADDED = /^\d{3,}\.png$/i;
const FRAME_SUFFIX = /^(.+?)(\d+)\.png$/i;

function isStrictSequenceFrame(name) {
  return (
    FRAME_NUMERIC.test(name) ||
    FRAME_TIMECODE.test(name) ||
    FRAME_PADDED.test(name)
  );
}

function naturalCompare(a, b) {
  const re = /(\d+)|(\D+)/g;
  const ax = [];
  const bx = [];
  let m;
  while ((m = re.exec(a))) ax.push(m[0]);
  re.lastIndex = 0;
  while ((m = re.exec(b))) bx.push(m[0]);
  const len = Math.max(ax.length, bx.length);
  for (let i = 0; i < len; i++) {
    const pa = ax[i];
    const pb = bx[i];
    if (pa === undefined) return -1;
    if (pb === undefined) return 1;
    const na = /^\d+$/.test(pa);
    const nb = /^\d+$/.test(pb);
    if (na && nb) {
      const diff = Number(pa) - Number(pb);
      if (diff !== 0) return diff;
    } else {
      const diff = pa.localeCompare(pb, undefined, { sensitivity: "base" });
      if (diff !== 0) return diff;
    }
  }
  return 0;
}

function naturalSort(names) {
  return [...names].sort(naturalCompare);
}

function groupByNumericSuffix(pngNames) {
  const groups = new Map();
  const ungrouped = [];

  for (const name of pngNames) {
    const m = name.match(FRAME_SUFFIX);
    if (m && m[1].length > 0) {
      const prefix = m[1];
      if (!groups.has(prefix)) groups.set(prefix, []);
      groups.get(prefix).push(name);
    } else {
      ungrouped.push(name);
    }
  }

  return { groups, ungrouped };
}

function isAtlasLike(relDir, pngNames) {
  const segments = relDir.split(/[/\\]/);
  const dirName = segments[segments.length - 1]?.toLowerCase() ?? "";
  const inImages = segments.some((s) => s.toLowerCase() === "images");
  const inSkeleton =
    segments.some((s) => /skeleton/i.test(s)) || /skeletondata/i.test(relDir);

  if (dirName === "images" && pngNames.length > 80) return true;
  if (inImages && inSkeleton && pngNames.length > 30) return true;
  if (inImages && pngNames.length > 120) return true;

  if (pngNames.length <= 80) return false;

  const { groups } = groupByNumericSuffix(pngNames);
  const groupSizes = [...groups.values()].map((g) => g.length).sort((a, b) => b - a);
  const largest = groupSizes[0] ?? 0;
  const largestRatio = largest / pngNames.length;

  if (largest < 12 && largestRatio < 0.2) return true;
  const bigGroups = groupSizes.filter((n) => n >= 8).length;
  if (bigGroups === 0 && pngNames.length > 100) return true;
  if (bigGroups >= 12 && pngNames.length > 200) return true;

  return false;
}

function classifyDirectory(absDir, relDir) {
  let entries;
  try {
    entries = fs.readdirSync(absDir, { withFileTypes: true });
  } catch {
    return [];
  }

  const pngs = entries
    .filter((e) => !e.isDirectory() && e.name.toLowerCase().endsWith(".png"))
    .map((e) => e.name);
  const gifs = entries
    .filter((e) => !e.isDirectory() && e.name.toLowerCase().endsWith(".gif"))
    .map((e) => e.name);

  const rel = relDir.replace(/\\/g, "/");
  const parts = rel.split("/");
  const effect = parts.length >= 2 ? parts[1] : parts[0] || "VFX";
  const version = parts[0] ?? "";
  const results = [];

  for (const gif of naturalSort(gifs)) {
    const label = gif.replace(/\.gif$/i, "");
    results.push({
      id: `${rel}#gif:${gif}`,
      type: "gif",
      sheetMode: "auto",
      version,
      effect,
      relDir: rel,
      label,
      frameCount: 1,
      poster: gif,
      frames: [gif],
    });
  }

  if (pngs.length < 2) return results;
  if (isAtlasLike(relDir, pngs)) return results;

  const strictCount = pngs.filter(isStrictSequenceFrame).length;
  const strictRatio = strictCount / pngs.length;

  if (strictRatio >= 0.5) {
    const frames = naturalSort(pngs);
    results.push({
      id: rel,
      version,
      effect,
      relDir: rel,
      label: path.basename(absDir),
      frameCount: frames.length,
      poster: frames[0],
      frames,
    });
    return results;
  }

  const { groups, ungrouped } = groupByNumericSuffix(pngs);

  for (const [prefix, files] of groups) {
    if (files.length < 2) continue;
    const frames = naturalSort(files);
    const suffix = prefix.replace(/[/\\?#%]/g, "_").replace(/_+$/, "") || "seq";
    results.push({
      id: `${rel}#${suffix}`,
      version,
      effect,
      relDir: rel,
      label: suffix,
      frameCount: frames.length,
      poster: frames[0],
      frames,
    });
  }

  const trailingDigitCount = pngs.filter((n) => /\d+\.png$/i.test(n)).length;
  if (
    results.length === 0 &&
    ungrouped.length <= 2 &&
    trailingDigitCount / pngs.length >= 0.6 &&
    pngs.length <= 120
  ) {
    const frames = naturalSort(pngs);
    results.push({
      id: rel,
      version,
      effect,
      relDir: rel,
      label: path.basename(absDir),
      frameCount: frames.length,
      poster: frames[0],
      frames,
    });
  }

  return results;
}

function scanTree(absDir, relDir, depth, sequences) {
  const top = relDir.split(/[\\/]/)[0];
  if (EXCLUDED_TOP_LEVEL_DIRS.has(top)) return;
  if (top.startsWith("vfx-browser-snapshot-")) return;

  const items = classifyDirectory(absDir, relDir);
  sequences.push(...items);

  if (depth >= MAX_DEPTH) return;

  let entries;
  try {
    entries = fs.readdirSync(absDir, { withFileTypes: true });
  } catch {
    return;
  }

  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    if (depth === 0 && EXCLUDED_TOP_LEVEL_DIRS.has(entry.name)) continue;
    const childAbs = path.join(absDir, entry.name);
    const childRel = relDir ? path.join(relDir, entry.name) : entry.name;
    scanTree(childAbs, childRel, depth + 1, sequences);
  }
}

function pathScore(relDir) {
  const r = relDir.replace(/\\/g, "/");
  let score = 0;
  if (r.includes("/images/")) score += 10;
  if (/skeletondata/i.test(r)) score += 5;
  return score;
}

function dedupeSequences(sequences) {
  const byKey = new Map();
  for (const seq of sequences) {
    const key = `${seq.version}|${seq.effect}|${seq.label}|${seq.frames.join(",")}`;
    const existing = byKey.get(key);
    if (!existing) {
      byKey.set(key, seq);
      continue;
    }
    const prefer = pathScore(seq.relDir) < pathScore(existing.relDir) ? seq : existing;
    byKey.set(key, prefer);
  }
  return [...byKey.values()];
}

function hashPosterFile(absDir, poster) {
  const filePath = path.join(absDir, poster);
  try {
    const buf = fs.readFileSync(filePath);
    return crypto.createHash("md5").update(buf).digest("hex");
  } catch {
    return null;
  }
}

function collectFolders(sequences) {
  const folders = new Set([""]);
  for (const seq of sequences) {
    const parts = seq.relDir.split("/");
    for (let i = 1; i <= parts.length; i++) {
      folders.add(parts.slice(0, i).join("/"));
    }
  }
  return [...folders].sort(naturalCompare);
}

function splitByContentHash(sequences) {
  const groups = new Map();

  for (const seq of sequences) {
    const absDir = path.join(VFX_ROOT, seq.relDir);
    const hash = hashPosterFile(absDir, seq.poster);
    seq.contentHash = hash;
    const key = `${hash ?? "none"}|${seq.frameCount}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(seq);
  }

  const canonical = [];
  const duplicates = [];

  for (const group of groups.values()) {
    if (group.length === 1 || !group[0].contentHash) {
      canonical.push(...group);
      continue;
    }

    group.sort((a, b) => pathScore(a.relDir) - pathScore(b.relDir));
    const keeper = group[0];
    keeper.canonical = true;
    canonical.push(keeper);

    for (let i = 1; i < group.length; i++) {
      const dup = group[i];
      dup.duplicateOf = keeper.id;
      dup.autoTrash = true;
      duplicates.push(dup);
    }
  }

  return { canonical, duplicates };
}

async function enrichWithTags(sequences) {
  const batchSize = 50;
  for (let i = 0; i < sequences.length; i += batchSize) {
    const batch = sequences.slice(i, i + batchSize);
    await Promise.all(
      batch.map(async (seq) => {
        seq.tags = await classifySequenceTags(seq, VFX_ROOT);
      })
    );
  }
}

async function main() {
  if (!fs.existsSync(VFX_ROOT)) {
    console.error(`VFX_ROOT not found: ${VFX_ROOT}`);
    process.exit(1);
  }

  const sequences = [];
  const t0 = Date.now();

  scanTree(VFX_ROOT, "", 0, sequences);

  const unique = dedupeSequences(sequences);
  unique.sort((a, b) => naturalCompare(a.relDir, b.relDir));

  console.log("Classifying tags...");
  await enrichWithTags(unique);

  const { canonical, duplicates } = splitByContentHash(unique);
  await enrichWithTags(duplicates);

  canonical.sort((a, b) => naturalCompare(a.relDir, b.relDir));
  duplicates.sort((a, b) => naturalCompare(a.relDir, b.relDir));

  const catalog = {
    vfxRoot: VFX_ROOT,
    generatedAt: new Date().toISOString(),
    sequenceCount: canonical.length,
    duplicateCount: duplicates.length,
    folders: collectFolders([...canonical, ...duplicates]),
    tagVocabulary: TAG_VOCABULARY,
    sequences: canonical,
    duplicates,
  };

  const outPath = path.join(OUT_DIR, "catalog.json");
  fs.writeFileSync(outPath, JSON.stringify(catalog, null, 2), "utf8");

  const ms = Date.now() - t0;
  console.log(
    `Wrote ${canonical.length} sequences + ${duplicates.length} duplicates to ${outPath} (${ms} ms)`
  );
}

main();

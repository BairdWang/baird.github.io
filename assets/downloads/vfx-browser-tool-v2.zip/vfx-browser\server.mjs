import fs from "node:fs";
import path from "node:path";
import http from "node:http";
import { execFile, spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, "public");
const CATALOG_PATH = path.join(__dirname, "catalog.json");
const USER_STATE_PATH = path.join(__dirname, "user-state.json");
const DEFAULT_VFX_ROOT = path.resolve(__dirname, "..");
const VFX_ROOT = path.resolve(process.env.VFX_ROOT || DEFAULT_VFX_ROOT);
const PORT = Number(process.env.PORT) || 5173;

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".gif": "image/gif",
  ".ico": "image/x-icon",
};

function send(res, status, body, headers = {}) {
  const payload = typeof body === "string" ? body : JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type":
      typeof body === "string" && !headers["Content-Type"]
        ? "text/plain; charset=utf-8"
        : "application/json; charset=utf-8",
    ...headers,
  });
  res.end(payload);
}

function sendJson(res, status, obj, extraHeaders = {}) {
  send(res, status, obj, {
    "Content-Type": "application/json; charset=utf-8",
    ...extraHeaders,
  });
}

function safeResolveUnderRoot(root, relPath) {
  const normalized = path.normalize(relPath).replace(/^(\.\.(\/|\\|$))+/, "");
  const abs = path.resolve(root, normalized);
  const rootResolved = path.resolve(root);
  if (!abs.startsWith(rootResolved + path.sep) && abs !== rootResolved) {
    return null;
  }
  return abs;
}

function readFileSafe(filePath) {
  try {
    return fs.readFileSync(filePath);
  } catch {
    return null;
  }
}

function readJsonSafe(filePath, fallback) {
  const raw = readFileSafe(filePath);
  if (!raw) return fallback;
  try {
    return JSON.parse(raw.toString("utf8"));
  } catch {
    return fallback;
  }
}

function sequenceExists(seq) {
  const dir = safeResolveUnderRoot(VFX_ROOT, seq.relDir);
  if (!dir || !fs.existsSync(dir)) return false;
  const posterPath = path.join(dir, seq.poster);
  return fs.existsSync(posterPath);
}

function loadCatalogRaw() {
  return readJsonSafe(CATALOG_PATH, null);
}

function filterExisting(items) {
  return items.filter(sequenceExists);
}

function serveCatalog(res) {
  const raw = loadCatalogRaw();
  if (!raw) {
    sendJson(res, 404, { error: "catalog.json missing — run npm run build" });
    return;
  }

  const sequences = filterExisting(raw.sequences ?? []);
  const duplicates = filterExisting(raw.duplicates ?? []);

  sendJson(
    res,
    200,
    {
      vfxRoot: raw.vfxRoot,
      generatedAt: raw.generatedAt,
      sequenceCount: sequences.length,
      duplicateCount: duplicates.length,
      folders: raw.folders ?? [],
      tagVocabulary: raw.tagVocabulary ?? { functions: [], colors: [] },
      sequences,
      duplicates,
    },
    { "Cache-Control": "no-cache" }
  );
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function openFolderInExplorer(absDir, posterFile) {
  return new Promise((resolve, reject) => {
    const posterPath = path.join(absDir, posterFile);
    const selectFile = fs.existsSync(posterPath);
    const win = process.platform === "win32";

    if (win && selectFile) {
      const child = spawn("explorer.exe", [`/select,${posterPath}`], {
        detached: true,
        stdio: "ignore",
        windowsHide: false,
      });
      child.once("error", reject);
      child.unref();
      resolve();
      return;
    }

    if (win) {
      const child = spawn("explorer.exe", [absDir], {
        detached: true,
        stdio: "ignore",
        windowsHide: false,
      });
      child.once("error", reject);
      child.unref();
      resolve();
      return;
    }

    if (process.platform === "darwin") {
      const args = selectFile ? ["-R", posterPath] : [absDir];
      execFile("open", args, (err) => (err ? reject(err) : resolve()));
      return;
    }

    execFile("xdg-open", [absDir], (err) => (err ? reject(err) : resolve()));
  });
}

async function handleOpenFolder(req, res) {
  let body;
  try {
    body = JSON.parse(await readBody(req));
  } catch {
    sendJson(res, 400, { error: "Invalid JSON" });
    return;
  }

  const relDir = body?.relDir;
  if (!relDir || typeof relDir !== "string") {
    sendJson(res, 400, { error: "relDir required" });
    return;
  }

  const absDir = safeResolveUnderRoot(VFX_ROOT, relDir);
  if (!absDir || !fs.existsSync(absDir)) {
    sendJson(res, 404, { error: "Folder not found" });
    return;
  }

  const poster = body?.poster;
  try {
    await openFolderInExplorer(absDir, poster);
    sendJson(res, 200, { ok: true });
  } catch (err) {
    sendJson(res, 500, { error: String(err.message || err) });
  }
}

function loadUserState() {
  const state = readJsonSafe(USER_STATE_PATH, { trashIds: [] });
  if (!Array.isArray(state.trashIds)) state.trashIds = [];
  return state;
}

function saveUserState(state) {
  state.updatedAt = new Date().toISOString();
  fs.writeFileSync(USER_STATE_PATH, JSON.stringify(state, null, 2), "utf8");
}

function handleUserStateGet(res) {
  sendJson(res, 200, loadUserState(), { "Cache-Control": "no-cache" });
}

async function handleUserStatePut(req, res) {
  let body;
  try {
    body = JSON.parse(await readBody(req));
  } catch {
    sendJson(res, 400, { error: "Invalid JSON" });
    return;
  }

  const state = loadUserState();
  if (Array.isArray(body.trashIds)) {
    state.trashIds = [...new Set(body.trashIds.map(String))];
  }
  if (body.addTrashId) {
    const id = String(body.addTrashId);
    if (!state.trashIds.includes(id)) state.trashIds.push(id);
  }
  if (body.removeTrashId) {
    const id = String(body.removeTrashId);
    state.trashIds = state.trashIds.filter((x) => x !== id);
  }

  saveUserState(state);
  sendJson(res, 200, state);
}

function serveStatic(req, res, urlPath) {
  let rel = urlPath === "/" ? "index.html" : urlPath.replace(/^\//, "");
  rel = rel.split("?")[0];
  const resolved = safeResolveUnderRoot(PUBLIC_DIR, rel);
  if (!resolved) {
    send(res, 403, "Forbidden");
    return;
  }
  const data = readFileSafe(resolved);
  if (!data) {
    send(res, 404, "Not Found");
    return;
  }
  const ext = path.extname(resolved).toLowerCase();
  res.writeHead(200, {
    "Content-Type": MIME[ext] || "application/octet-stream",
    "Cache-Control": ext === ".html" ? "no-cache" : "public, max-age=3600",
  });
  res.end(data);
}

function serveMedia(req, res, urlPath) {
  const prefix = "/media/";
  if (!urlPath.startsWith(prefix)) {
    send(res, 404, "Not Found");
    return;
  }

  const rest = decodeURIComponent(urlPath.slice(prefix.length));
  const slash = rest.lastIndexOf("/");
  if (slash < 0) {
    send(res, 400, "Bad Request");
    return;
  }

  const relDir = rest.slice(0, slash);
  const fileName = rest.slice(slash + 1);

  if (!fileName || fileName.includes("/") || fileName.includes("\\")) {
    send(res, 400, "Bad Request");
    return;
  }

  const absDir = safeResolveUnderRoot(VFX_ROOT, relDir);
  if (!absDir) {
    send(res, 403, "Forbidden");
    return;
  }

  const absFile = path.join(absDir, fileName);
  const fileResolved = path.resolve(absFile);
  if (!fileResolved.startsWith(absDir + path.sep)) {
    send(res, 403, "Forbidden");
    return;
  }

  const data = readFileSafe(fileResolved);
  if (!data) {
    send(res, 404, "Not Found");
    return;
  }

  res.writeHead(200, {
    "Content-Type": MIME[path.extname(fileResolved).toLowerCase()] || "application/octet-stream",
    "Cache-Control": "public, max-age=86400",
  });
  res.end(data);
}

const server = http.createServer(async (req, res) => {
  const urlPath = decodeURIComponent(
    new URL(req.url, `http://127.0.0.1:${PORT}`).pathname
  );

  if (urlPath === "/api/catalog" && req.method === "GET") {
    serveCatalog(res);
    return;
  }

  if (urlPath === "/api/open-folder" && req.method === "POST") {
    await handleOpenFolder(req, res);
    return;
  }

  if (urlPath === "/api/user-state") {
    if (req.method === "GET") {
      handleUserStateGet(res);
      return;
    }
    if (req.method === "PUT") {
      await handleUserStatePut(req, res);
      return;
    }
  }

  if (urlPath === "/catalog.json") {
    serveCatalog(res);
    return;
  }

  if (urlPath.startsWith("/media/")) {
    serveMedia(req, res, urlPath);
    return;
  }

  if (req.method === "GET") {
    serveStatic(req, res, urlPath);
    return;
  }

  send(res, 404, "Not Found");
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`VFX browser: http://127.0.0.1:${PORT}`);
  console.log(`VFX_ROOT: ${VFX_ROOT}`);
  if (!fs.existsSync(CATALOG_PATH)) {
    console.warn("catalog.json missing — run: npm run build");
  }
});
